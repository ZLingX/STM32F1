#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "BMP280.h"
#include "math.h"
int main (void)
{
	uint8_t ID;
	OLED_Init();
	Bmp_Init();
	ID=BMP280_ReadID();          //���ID��
	OLED_ShowString(1,1,"ID:");
	OLED_ShowString(2,1,"P:");   //��ô���ѹǿ
	OLED_ShowString(3,1,"T:");   //����¶�
	OLED_ShowHexNum(1, 4, ID, 4);

	while (1)
	{

		OLED_ShowNum(2,3,BMP280_Get_Pressure(),6);
		OLED_ShowNum(3,3,BMP280_Get_Temperature(),6);
	}
}


