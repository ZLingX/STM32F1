#include "sys.h"                  // Device header

void MyENCODER_Init(
/*��TIMʱ��*/
uint32_t RCC_APBXPeriph_TIMY1,
/*
C8T6��ֻ��TIM1��RCC_APB2PeriphClockCmd��2��3��4����RCC_APB1PeriphClockCmd
��Ҫʹ��TIM1��Ҫ�ֶ��Ĵ���
*/
/*RCC_APB2Periph_TIM1 RCC_APB1Periph_TIM2 RCC_APB1Periph_TIM3 RCC_APB1Periph_TIM4 */

/*��GPIOʱ��*/
uint32_t RCC_APBXPeriph_GPIOY2,
/*RCC_APB2Periph_GPIOA RCC_APB2Periph_GPIOB*/

/*GPIO*/
uint16_t GPIO_Pin_X,/*ѡ�������ⲿʱ�ӵ�����*/

GPIO_TypeDef * GPIOX,/* GPIOA GPIOB */

/*ʱ����Ԫ��ʱ��Դ��ʱ����Ԫ��ʼ����ʹ�ܼ�����*/
TIM_TypeDef * TIMX/* TIM1 TIM2 TIM3 TIM4 */
)
{
	RCC_APB2PeriphClockCmd(RCC_APBXPeriph_GPIOY2,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APBXPeriph_TIMY1,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_X; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOX,&GPIO_InitStructure);
	
	TIM_TimeBaseInitTypeDef TimeBase_InitStructure;
	TimeBase_InitStructure.TIM_ClockDivision=TIM_CKD_DIV1;
	TimeBase_InitStructure.TIM_CounterMode=TIM_CounterMode_Up;
	TimeBase_InitStructure.TIM_Period=65536-1;
	TimeBase_InitStructure.TIM_Prescaler =1-1;
	TimeBase_InitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIMX,&TimeBase_InitStructure);
	
	TIM_ICInitTypeDef TIM_ICInitStructure;
	TIM_ICStructInit(&TIM_ICInitStructure);
//	TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;
	TIM_ICInitStructure.TIM_ICFilter = 0xF;
//	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
	TIM_ICInit(TIMX,&TIM_ICInitStructure);
//	TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;
	TIM_ICInitStructure.TIM_ICFilter = 0xF;
//	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
	TIM_ICInit(TIMX,&TIM_ICInitStructure);
	TIM_EncoderInterfaceConfig(TIMX,TIM_EncoderMode_TI12,TIM_ICPolarity_Rising,TIM_ICPolarity_Rising);
	/*TIM_EncoderInterfaceConfig���������ظ�����*/
	
	TIM_Cmd(TIMX,ENABLE);
}
