#include "stm32f10x.h"
#include "oled.h"
#include "delay.h"
#include "DHT11.h"

extern  DHT11_Data_TypeDef DHT11_Data;

int main(void)
{ 
	delay_init();
	OLED_Init();
	OLED_Clear();
	DHT11_GPIO_Config();
	
	OLED_ShowCHinese(0,0,0);
	OLED_ShowCHinese(16,0,1);
	OLED_ShowChar(32,0,':',16);
	OLED_ShowCHinese(0,2,12);
	OLED_ShowCHinese(16,2,1);
	OLED_ShowChar(32,2,':',16);
  
  while (1)
  {
		if(Read_DHT11(&DHT11_Data) == SUCCESS)
		{
			OLED_ShowNumber(40,0,DHT11_Data.temp_int,2,16);
			OLED_ShowChar(56,0,'.',16);
      OLED_ShowNumber(64,0,DHT11_Data.temp_deci,1,16);
		  OLED_ShowCHinese(72,0,4);

			OLED_ShowNumber(40,2,DHT11_Data.humi_int,2,16);
		  OLED_ShowString(56,2,"%RH",16);
			
			delay_ms(100);
		}
  }
}
