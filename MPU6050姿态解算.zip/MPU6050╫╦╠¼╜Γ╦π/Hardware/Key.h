#ifndef __KEY_H
#define __KEY_H

#include "sys.h"

void Key0_Init(void);
void Key1_Init(void);
void Key_Init(void);
uint8_t Key_GetNum(void);

#endif
