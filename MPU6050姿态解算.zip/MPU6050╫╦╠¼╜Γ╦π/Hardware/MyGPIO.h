#ifndef __MyGPIO_H_
#define __MyGPIO_H_

typedef enum
{ 
		GPIO_FK_IN=0,
		GPIO_AD_IN=1,

		GPIO_KL_OUT=2,
		GPIO_KL_AF_OUT=3,
		GPIO_TW_OUT=4,
		GPIO_TW_AF_OUT=5,

	  GPIO_P_NO=6,
		GPIO_P_UP=7,
		GPIO_P_DOWN=8,

		GPIO_2MHz=9,
		GPIO_10MHz=10,
		GPIO_25MHz=11,
		GPIO_50MHz=12,
		GPIO_100MHz=13
}MyGPIO_TypeDef;

void MyGPIO_Init(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin,MyGPIO_TypeDef mode,MyGPIO_TypeDef up_down,MyGPIO_TypeDef speed);

#endif
