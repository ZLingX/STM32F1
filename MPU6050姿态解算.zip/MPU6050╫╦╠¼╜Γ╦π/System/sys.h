#ifndef __SYS_H
#define __SYS_H	 

#include "stm32f10x.h"
#include "delay.h"
#include "LED.h"
#include "Key.h"
#include "OLED.h"

#include "usart.h"
#include "MyTIM.h"
#include "MyPWM.h"
#include "MyEXTI.h"
#include "MyENCODER_IC.h"
#include "MyUSART.h"
#include "AD.h"
#include "MyIIC.h"

#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "mpu6050.h"
#include "MPU6050_I2C.h"

//#include "motor.h"
//#include "encoder.h"
//#include "control.h"

#include <string.h> 
#include <stdio.h>
#include <stdarg.H>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "BitBand.h"

//JTAGģʽ���ö���
#define JTAG_SWD_DISABLE   0X02
#define SWD_ENABLE         0X01
#define JTAG_SWD_ENABLE    0X00	

typedef enum
{ 
		GPIO_FK_IN=0,
		GPIO_AD_IN=1,

		GPIO_KL_OUT=2,
		GPIO_KL_AF_OUT=3,
		GPIO_TW_OUT=4,
		GPIO_TW_AF_OUT=5,

	  GPIO_P_NO=6,
		GPIO_P_UP=7,
		GPIO_P_DOWN=8,

		GPIO_2MHz=9,
		GPIO_10MHz=10,
		GPIO_25MHz=11,
		GPIO_50MHz=12,
		GPIO_100MHz=13
}MyGPIO_TypeDef;


void MyGPIO_Init(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin,MyGPIO_TypeDef mode,MyGPIO_TypeDef up_down,MyGPIO_TypeDef speed);

//extern uint8_t MyUSART_RxData;
//extern uint8_t MyUSART_RxFlag;
//extern int RxData;
//extern uint16_t ADValue0,ADValue1,ADValue2,ADValue3,ADValue4,ADValue5;
//extern float Pitch,Roll,Yaw;		//�Ƕ�
//extern short gyrox,gyroy,gyroz;	//������--���ٶ�
//extern short aacx,aacy,aacz;		//���ٶ�
//extern float Temperature;
//extern int Encoder_L,Encoder_R;
//extern int Motor_L,Motor_R;
//extern float Vertical_out,Velocity_out,Turn_out;
//extern float Med_Angle;
//extern float Target_Speed;
//extern float Target_Angle;
//extern uint8_t RxData;;
//extern int Target_Speed_Flag;

#endif

