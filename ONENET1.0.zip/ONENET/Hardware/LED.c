#include "sys.h"                  // Device header

void LED1_Init()/*PA8*/
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
//	GPIO_SetBits(GPIOC,GPIO_Pin_6);
	LED1_ON();
}

void LED2_Init()/*PD2*/
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD,&GPIO_InitStructure);
	LED2_OFF();
}

void LED_Init()
{
  LED1_Init();
	LED2_Init();
}

void LED1_ON()
{
	GPIO_ResetBits(GPIOC,GPIO_Pin_7);
}

void LED1_OFF()
{
	GPIO_SetBits(GPIOA,GPIO_Pin_8);
}

void LED2_ON()
{
	GPIO_ResetBits(GPIOD,GPIO_Pin_2);
}

void LED2_OFF()
{
	GPIO_SetBits(GPIOD,GPIO_Pin_2);
}

void LED1_Turn()
{
	if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_8)!=0)
	{
	  GPIO_ResetBits(GPIOA,GPIO_Pin_8);
	}
	else
	{
	  GPIO_SetBits(GPIOA,GPIO_Pin_8);
	}
}

void LED2_Turn()
{
	if(GPIO_ReadOutputDataBit(GPIOD,GPIO_Pin_2)!=0)
	{
	  GPIO_ResetBits(GPIOD,GPIO_Pin_2);
	}
	else
	{
	  GPIO_SetBits(GPIOD,GPIO_Pin_2);
	}
}
