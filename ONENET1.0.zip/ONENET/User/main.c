#include "sys.h"

int main(void)
{

	unsigned char *dataPtr = NULL;
	
	delay_init();
	OLED_Init();
	temperature=-20;
	ESP8266_Init();
	
	
	
	while (1)
	{
//		DHT11_Read_Data(&temperature,&humidity);		//��ȡ��ʪ��ֵ
//		delay_ms(100);
	
//					data_len=MqttOnenet_Savedata(send_jason,temperature, humidity);
			OneNet_SendData();									//��������
			ESP8266_Clear();				
			dataPtr = ESP8266_GetIPD(0);
			if(dataPtr != NULL)
			OneNet_RevPro(dataPtr);
      
			delay_ms(5000);
			temperature+=0.1;
	}
}


