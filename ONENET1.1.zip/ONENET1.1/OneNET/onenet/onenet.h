#ifndef _ONENET_H_
#define _ONENET_H_


#define PROID			"38rKUffz1T"

#define ACCESS_KEY		"d2xEVjlSYUtMWnp4TWtPUGFqY3o5NjlZTWRNR1pqa0g="

#define DEVICE_NAME		"STM32DHT11"


_Bool OneNET_RegisterDevice(void);

_Bool OneNet_DevLink(void);

void OneNet_SendData(void);

void OneNET_Subscribe(void);

void OneNet_RevPro(unsigned char *cmd);

#endif
