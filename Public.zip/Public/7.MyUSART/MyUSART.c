#include "sys.h"                  // Device header

uint8_t MyUSART_RxData;
uint8_t MyUSART_RxFlag;
uint8_t RxData;


void MyUSART_Init(
	/*GPIO*/
	uint32_t RCC_APB2Periph_GPIOX,/* RCC_APB2Periph_GPIOA  RCC_APB2Periph_GPIOB  RCC_APB2Periph_GPIOC... */
  uint16_t GPIO_Pin_X1,/* GPIO_Pin_Number TXD */
  uint16_t GPIO_Pin_X2,/* GPIO_Pin_Number RXD */
  GPIO_TypeDef * GPIOX,/*GPIO��ʼ�� GPIOA GPIOB  GPIOC */
  
  /*USART*/
  uint32_t RCC_APBXPeriph_USARTY,/* RCC_APB2Periph_USART1 RCC_APB1Periph_USART2 RCC_APB1Periph_USART3 */
  USART_TypeDef * USARTX,/* USART1 USART2 USART3 */
  
  /*NVIC*/
  uint8_t USARTX_IRQn,/* USART1_IRQn USART2_IRQn USART3_IRQn */
	uint8_t PreemptionPriority,/*According to the NVIC_PriorityGroup*/
	uint8_t SubPriority/*According to the NVIC_PriorityGroup*/
)
{
	if(USARTX==USART1)
	RCC_APB2PeriphClockCmd(RCC_APBXPeriph_USARTY,ENABLE);
	else
	RCC_APB1PeriphClockCmd(RCC_APBXPeriph_USARTY,ENABLE);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOX,ENABLE);
	
	USART_DeInit(USARTX);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_X1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOX, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_X2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOX, &GPIO_InitStructure);
	
	USART_InitTypeDef Usart_InitStructure;
	/*������*/
	Usart_InitStructure.USART_BaudRate = 9600;
	/*Ӳ��������*/
	Usart_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	/*����ģʽ*/
	Usart_InitStructure.USART_Mode = USART_Mode_Tx|USART_Mode_Rx;
	/*У��λ*/
	Usart_InitStructure.USART_Parity = USART_Parity_No;
	/*ֹͣλ*/
	Usart_InitStructure.USART_StopBits = USART_StopBits_1;
	/*�ֳ�*/
	Usart_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USARTX,&Usart_InitStructure);
	/*�����ж�*/
	USART_ITConfig(USARTX,USART_IT_RXNE,ENABLE);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel= USARTX_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=PreemptionPriority;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=SubPriority;
	NVIC_Init(&NVIC_InitStructure);
	/*����*/
	USART_Cmd(USARTX,ENABLE);
}

void MyUSART_SendByte(USART_TypeDef * USARTX,uint8_t Byte)
{
	USART_SendData(USARTX,Byte);
	while(USART_GetFlagStatus(USARTX,USART_FLAG_TXE)==RESET);
}

void MyUSART_SendArray(USART_TypeDef * USARTX,uint8_t *Array,uint16_t Length)
{
	uint16_t i;
	for(i=0;i<Length;i++)
	{
	  MyUSART_SendByte(USARTX,Array[i]);
	}
}

void MyUSART_SendString(USART_TypeDef * USARTX,char* String)//  "String"
{
	uint8_t i;
  for(i=0;String[i] != '\0';i++)//for(i=0;String[i] != 0;i++)
	{
		MyUSART_SendByte(USARTX,String[i]);
	}
}

uint32_t MyUSART_Pow(uint32_t x,uint32_t y)
{
  uint32_t Result=1;
	while(y--){Result*=x;}
	return Result;
}

void MyUSART_SendNum(USART_TypeDef * USARTX,uint32_t Number,uint8_t Length)
{
	uint8_t i;
	for(i=0;i<Length;i++)
	{
		MyUSART_SendByte(USARTX,Number/MyUSART_Pow(10,Length-i-1)%10+'0');
	}
}

///*print����*/
//int fputc(int ch, FILE *f)
//{
//	MyUSART_SendByte(ch);
//	return ch;
//}

/*��װsprint*/
void MyUSART_Printf(USART_TypeDef * USARTX,char *format, ...)
{
	char String[100];
	va_list arg;
	va_start(arg,format);
	vsprintf(String,format,arg);
	va_end(arg);
	MyUSART_SendString(USARTX,String);
}

uint8_t MyUSART_GetRxFlag()
{
  if(MyUSART_RxFlag==1)
  {
	 MyUSART_RxFlag=0;
	 return 1;
  }
	return 0;
}

uint8_t MyUSART_GetRxData()
{
  return MyUSART_RxData;
}
