#ifndef __MyUSART_H_
#define __MyUSART_H_

#include "sys.h"

void MyUSART_Init(
	/*GPIO*/
	uint32_t RCC_APB2Periph_GPIOX,/* RCC_APB2Periph_GPIOA  RCC_APB2Periph_GPIOB  RCC_APB2Periph_GPIOC... */
  uint16_t GPIO_Pin_X1,/* GPIO_Pin_Number TXD */
  uint16_t GPIO_Pin_X2,/* GPIO_Pin_Number RXD */
  GPIO_TypeDef * GPIOX,/*GPIO��ʼ�� GPIOA GPIOB  GPIOC */
  
  /*USART*/
  uint32_t RCC_APBXPeriph_USARTY,/* RCC_APB2Periph_USART1 RCC_APB1Periph_USART2 RCC_APB1Periph_USART3 */
  USART_TypeDef * USARTX,/* USART1 USART2 USART3 */
  
  /*NVIC*/
  uint8_t USARTX_IRQn,/* USART1_IRQn USART2_IRQn USART3_IRQn */
	uint8_t PreemptionPriority,/*According to the NVIC_PriorityGroup*/
	uint8_t SubPriority/*According to the NVIC_PriorityGroup*/
);
void MyUSART_SendByte(USART_TypeDef * USARTX,uint8_t Byte);
void MyUSART_SendArray(USART_TypeDef * USARTX,uint8_t *Array,uint16_t Length);
void MyUSART_SendString(USART_TypeDef * USARTX,char* String);
uint32_t MyUSART_Pow(uint32_t x,uint32_t y);
void MyUSART_SendNum(USART_TypeDef * USARTX,uint32_t Number,uint8_t Length);
void MyUSART_Printf(USART_TypeDef * USARTX,char *format, ...);
uint8_t MyUSART_GetRxFlag(void);
uint8_t MyUSART_GetRxData(void);

#endif

/************************USARTӦ�ú���************************/
//int RxData;

//if(MyUSART_GetRxFlag()==1)
//{
//	RxData=MyUSART_GetRxData();
//}
/**********************USARTͨ��������**********************/
//void USARTX_IRQHandler()
//{
//  if(USART_GetFlagStatus(USART1,USART_FLAG_RXNE)==SET)
//  {
//	  MyUSART_RxData=USART_ReceiveData(USART1);
//	  
//    MyUSART_RxFlag=1;
//	
//	USART_ClearITPendingBit(USART1,USART_FLAG_RXNE);
//  }
//}
