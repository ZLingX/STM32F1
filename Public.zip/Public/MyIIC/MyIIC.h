#ifndef __MyIIC_H_
#define __MyIIC_H_

#include "sys.h"

#define MyIIC_WriteMode 			0x00
#define MyIIC_ReadMode      	0x01
#define MyIIC_WriteDataMode 	0x40

#define OLEDAddress						0x78
#define BMP280Address					0x76
#define MPU6050_ADDRESS		    0xD0

void MyIIC_W_SCL(uint8_t BitValue);
uint8_t MyIIC_R_SCL(void);
void MyIIC_W_SDA(uint8_t BitValue);
uint8_t MyIIC_R_SDA(void);
void MyIIC_GPIO_Init(void);
void MyIIC_Start(void);
void MyIIC_Stop(void);
void MyIIC_SendByte(uint8_t Byte);
void MyIIC_OLED_SendByte(uint8_t Byte);/*���ƴ�OLEDר��*/
uint8_t MyIIC_ReceiveByte(void);
void MyIIC_SendAck(uint8_t AckBit);
uint8_t MyIIC_ReceiveAck(void);
char MyIIC_WaitAck(void);
void MyIIC_WriteReg(uint8_t SlaveAddress,uint8_t RegAddress,uint8_t Data);
uint8_t MyIIC_ReadReg(uint8_t SlaveAddress,uint8_t RegAddress);










#endif
