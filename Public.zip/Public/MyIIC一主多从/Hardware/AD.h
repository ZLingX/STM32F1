#ifndef __AD_H_
#define __AD_H_

void AD_Init(void);
//uint16_t AD_GetValue(void);
uint16_t AD_GetValue(uint16_t ADC_Channel);

#endif
