#ifndef __DELAY_H
#define __DELAY_H 	

#include "sys.h"  
/*OSר������*/
void delay_init(void);
void delay_ms(u16 nms);
void delay_us(u32 nus);
/*delay2Ϊ���ƴ����*/
void delay2_us(uint32_t us);
void delay2_ms(uint32_t ms);
void delay2_s(uint32_t s);

#endif





























