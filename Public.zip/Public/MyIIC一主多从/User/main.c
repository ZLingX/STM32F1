#include "sys.h"

int16_t P,R,Y;
float BMP;

int main(void)
{
	OLED_Init();
	OLED_Boot_Animation();
	OLED_ShowString(0,0,"MPUID:",OLED_8X16);
	OLED_ShowString(0,16,"Pitch:",OLED_8X16);
	OLED_ShowString(0,32,"BMPID:",OLED_8X16);
	OLED_ShowString(0,48,"BMP:",OLED_8X16);
	
	MPU6050_Init();
	OLED_ShowHexNum(48,0,MPU6050_GetID(),2,OLED_8X16);

  Bmp_Init();	
	OLED_ShowHexNum(48,32,BMP280_ReadID(),2,OLED_8X16);
	
	OLED_Update();
	while (1)
	{
		/*MPU6050*/
		MPU6050_GetData(&P,&R,&Y);
		
		/*BMP280*/
		BMP=BMP280_Get_Pressure();
		
		/*OLED*/
		OLED_ShowSignedNum(48,16,P,4,OLED_8X16);
		OLED_ShowNum(32,48,BMP,6,OLED_8X16);
		OLED_Update();
		
//		/*Delay*/
//		delay2_ms(100);
	}
}
