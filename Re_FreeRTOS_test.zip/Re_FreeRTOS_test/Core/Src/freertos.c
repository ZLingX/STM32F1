/* USER CODE BEGIN Header */
#include "sys.h"

uint8_t Tx_Buf_Num[]={
1,2,3,4,5
};

uint8_t Tx_Buf_HEX[]={
0x41,0x42,0x43,0x44
};

uint8_t Tx_Buf_Char[]={
'O','K','c','d'
};

uint8_t Rx_Buf_Num[5]={
0,0,0,0,0
};

double temperature=26,humidity=50;
int temp,humi;
unsigned char *dataPtr = NULL;
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
	LCD_Init();
	LCD_Clear();
	DHT11_Init();
	HAL_UART_Receive_IT(&huart1, Rx_Buf_Num, 5);/*串口中断需要先执行HAL_UART_Receive_IT*/
	ESP8266_Init();
  /* Infinite loop */
  for(;;)
  {
//    OLED_Test();
//		LCD_Test();
//		Key_Test();
//		Led_Test();
//		ActiveBuzzer_Test();
//		PassiveBuzzer_Test();
//		DHT11_Test();
//		DS18B20_Test();
//		IRObstacle_Test();
//		LightSensor_Test();
//		MPU6050_Test();
//		W25Q64_Test();
//		SR04_Test();
//		RotaryEncoder_Test();
//		IRReceiver_Test();
//		IRSender_Test();
//		printf(" 你好，世界！\r\n");
//		HAL_Delay(500);
		DHT11_Read(&humi,&temp);
		temperature=(double)temp;
		humidity=(double)humi;
		OneNet_SendData();	//发送数据
		ESP8266_Clear();	//清空数据缓存区
//		dataPtr = ESP8266_GetIPD(0);
//		if(dataPtr != NULL)
//		OneNet_RevPro(dataPtr);
		HAL_Delay(5000);	//5s发送一次
  }
  /* USER CODE END StartDefaultTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */



/* USER CODE END Application */

