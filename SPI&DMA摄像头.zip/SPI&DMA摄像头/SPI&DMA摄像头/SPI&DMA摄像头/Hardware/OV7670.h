#ifndef _OV7660_H
#define _OV7660_H

#include "sys.h"

#define OV7670_VSYNC_PORT     GPIOA  
#define FIFO_WRST_PORT        GPIOA  
#define FIFO_WEN_PORT         GPIOB  
#define FIFO_RRST_PORT        GPIOA  
#define FIFO_OE_PORT          GPIOA  
#define FIFO_RCLK_PORT        GPIOB  

#define OV7670_VSYNC_PIN      GPIO_Pin_2   
#define FIFO_WRST_PIN         GPIO_Pin_3   
#define FIFO_WEN_PIN          GPIO_Pin_6   
#define FIFO_RRST_PIN         GPIO_Pin_9   
#define FIFO_OE_PIN           GPIO_Pin_10  
#define FIFO_RCLK_PIN         GPIO_Pin_5
                                                     //PA0����SCL��PA1����SDA����sccb.h�鿴
#define OV7670_VSYNC          PAin(2)                //PA2֡�ź�
#define FIFO_WRST		          PAout(3)		           //PA3дָ�븴λ
#define FIFO_WEN		          PBout(6)		           //PA4д��FIFOʹ��
#define FIFO_RRST		          PAout(9)  		         //PA11��ָ�븴λ
#define FIFO_OE		            PAout(10)  		         //PA12Ƭѡ�ź�(OE)
#define FIFO_RCLK	            PBout(5)               //PB5������ʱ��

#define OV7670_RedData()      (GPIOB->IDR & 0XFF00)  //������PB8-PB15

#define lightmode  0
#define saturation 2
#define brightness 2
#define contrast   2
#define effect     0

extern uint8_t OV7670_STA;
void camera_refresh(void);
void fifo_count_OV7670_STA(void);
unsigned char OV7670_Init(void);
void OV7670_Window_Set(u16 sx,u16 sy,u16 width,u16 height);

#endif
