#ifndef __SYS_H
#define __SYS_H	 

#include "stm32f10x.h"

#include "delay.h"

#include "LED.h"
#include "OLED.h"
#include "Key.h"

#include "usart.h"
#include "MyTIM.h"
#include "MyPWM.h"
#include "MyEXTI.h"
#include "MyENCODER_IC.h"
#include "MyUSART.h"
#include "MyIIC.h"

#include "SCCB.h"
#include "OV7670.h"
#include "spi.h"
#include "dma.h"
#include "lcd_init.h"

//#include "inv_mpu.h"
//#include "inv_mpu_dmp_motion_driver.h"
//#include "mpu6050.h"

//#include "motor.h"
//#include "encoder.h"
//#include "control.h"

#include <string.h> 
#include <stdio.h>
#include <stdarg.H>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "BitBand.h"

//Ex_NVIC_Configר�ö���
#define GPIO_A 0
#define GPIO_B 1
#define GPIO_C 2
#define GPIO_D 3
#define GPIO_E 4
#define GPIO_F 5
#define GPIO_G 6 

#define FTIR   1  //�½��ش���
#define RTIR   2  //�����ش���

//JTAGģʽ���ö���
#define JTAG_SWD_DISABLE   0X02
#define SWD_ENABLE         0X01
#define JTAG_SWD_ENABLE    0X00	


typedef enum
{ 
		GPIO_FK_IN=0,
		GPIO_AD_IN=1,

		GPIO_KL_OUT=2,
		GPIO_KL_AF_OUT=3,
		GPIO_TW_OUT=4,
		GPIO_TW_AF_OUT=5,

	  GPIO_P_NO=6,
		GPIO_P_UP=7,
		GPIO_P_DOWN=8,

		GPIO_2MHz=9,
		GPIO_10MHz=10,
		GPIO_25MHz=11,
		GPIO_50MHz=12,
		GPIO_100MHz=13
}MyGPIO_TypeDef;


void MyGPIO_Init(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin,MyGPIO_TypeDef mode,MyGPIO_TypeDef up_down,MyGPIO_TypeDef speed);


//extern uint8_t MyUSART_RxData;
//extern uint8_t MyUSART_RxFlag;
//extern int RxData;
//extern float Pitch,Roll,Yaw;		//�Ƕ�
//extern short gyrox,gyroy,gyroz;	//������--���ٶ�
//extern short aacx,aacy,aacz;		//���ٶ�
//extern float Temperature;
//extern int Encoder_L,Encoder_R;
//extern int Motor_L,Motor_R;
//extern float Vertical_out,Velocity_out,Turn_out;
//extern float Med_Angle;
//extern float Target_Speed;
//extern float Target_Angle;
//extern uint8_t RxData;;
//extern int Target_Speed_Flag;

void NVIC_Config(void);
void NVIC_Configuration(void);
void RCC_Configuration(void);//RCCʱ�ӵ�����  



#endif

