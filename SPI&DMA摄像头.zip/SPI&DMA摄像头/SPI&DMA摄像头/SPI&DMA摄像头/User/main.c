#include "sys.h"

int main(void)
{
	RCC_Configuration();
	delay_init();
	LCD_Init();
	OV7670_Init();
	MyEXTI_Init(RCC_APB2Periph_GPIOA,GPIO_Pin_2,GPIOA,GPIO_PortSourceGPIOA,GPIO_PinSource2,EXTI_Line2,EXTI2_IRQn,1,1);
	while (1)
	{		
		

	}
}

void EXTI2_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line2) == SET)	//��8�ߵ��ж�
	{      
		fifo_count_OV7670_STA();
		camera_refresh();
	}
	EXTI_ClearITPendingBit(EXTI_Line2);  //���EXTI8��·����λ						
}

