#include "stm32f10x.h"                  // Device header
#include "PWM.h"

void Servo_Init()
{
  PWM_Init();
}

void Set_Angle(float Angle)/*0~180*/
{
	PWM_SetCompare2(2000/180*Angle+500);
}

