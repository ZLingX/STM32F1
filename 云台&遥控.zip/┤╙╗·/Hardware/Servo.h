#ifndef __SERVO_H_
#define __SERVO_H_

void Servo_Init(void);
void Set_Angle(float Angle);

#endif
