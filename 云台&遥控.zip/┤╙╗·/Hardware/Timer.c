#include "stm32f10x.h"                  // Device header

void Timer_Init()
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	//开启TIM3时钟
	
	TIM_InternalClockConfig(TIM3);
	//选择时基单元的时钟源（开启默认为内部时钟驱动）
	
	TIM_TimeBaseInitTypeDef TimeBase_InitStructure;
	//配置时基单元
	TimeBase_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	//指定时钟分频（用于滤波，该参数与时基单元关系不大，随意配置即可）
	TimeBase_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	//配置计数器 CNT
	TimeBase_InitStructure.TIM_Period = 100-1;
	//配置自动重装器（周期）ARR
	TimeBase_InitStructure.TIM_Prescaler = 720-1;
	//配置预分频器（分频）PSC
	//以7200的分频执行10000个周期
					/*
					关于自动重装值和分频器值
					定时频率（多久进入一次中断） = 72M /（PSC+1）/（ARR+1）
					若要配置1s定时，则如下
					自动重装值大，分频值小  70MHz=(9999+1)*(719+1)
					自动重装值小，分频值大  70MHz=(7199+1)*(9999+1)
					*/
	TimeBase_InitStructure.TIM_RepetitionCounter = 0;
	//配置重复计数器（高级定时器才需配置，不需要直接给0）
	TIM_TimeBaseInit(TIM3,&TimeBase_InitStructure);
	//时基单元初始化
			/*
			区别于TIM_TimeBaseStructInit()设置默认配置
			*/

	TIM_ClearFlag(TIM3,TIM_IT_Update);
  //清除标志，避免刚初始化完就进入中断（在时基单元初始化后，使能定时器前完成）

	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
  //使能中断输出控制，使能后进入NVIC
	
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM3, ENABLE);
	//使能计数器（运行控制）
}

/*模板为1ms
void TIM3_IRQHandler()
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET)
	{ 
		Counter++;
		if(Counter==1000)
    {
			Counter=0;

    }
	}
  TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
}
*/
