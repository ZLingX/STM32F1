#ifndef __Timer_H_
#define __Timer_H_

void Timer_Init(void);

#endif
