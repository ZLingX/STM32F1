#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "Servo.h"
#include "Timer.h"

uint8_t RxData,Angle=90;
uint16_t Counter;

int main(void)
{
	OLED_Init();
	Serial_Init();
	Servo_Init();
	Timer_Init();
	OLED_ShowString(1,1,"RxData:");
	OLED_ShowString(2,1,"Angle:");
	while (1)
	{
		if(Serial_GetRxFlag()==1)
		{
			RxData = Serial_GetRxData();
		}
		
		
		Set_Angle(Angle);
		OLED_ShowNum(2,7,Angle,3);
		OLED_ShowHexNum(1,8,RxData,2);
	}
}

void TIM3_IRQHandler()//1ms
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET)
	{ 
		Counter++;
		if(Counter==25)
    {
			Counter=0;
		  if(RxData==0x01){Angle-=1;if(Angle<1){Angle=1;}}
		  if(RxData==0x02){Angle+=1;if(Angle>179){Angle=179;}}
    }
	}
  TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
}
