#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "Key.h"

uint8_t TxData,KeyNum;

int main(void)
{
	OLED_Init();
	Key_Init();
	OLED_ShowString(1, 1, "TxData:");
	
	Serial_Init();
	
	while (1)
	{
		KeyNum=Key_GetNum();
		if(KeyNum==1)
		{
		TxData=0x01;
		}
		else if(KeyNum==2)
		{
		TxData=0x02;
		}
		else
		{
		TxData=0x00;
		}
		Serial_SendByte(TxData);
		OLED_ShowHexNum(1, 8, TxData, 2);
	}
}
