#ifndef __Ultrasonic_H_
#define __Ultrasonic_H_

void HC_SR04_Init(void);
void HC_SR04_Start(void);
uint16_t HCSR04_Get_Data(void);

#endif
