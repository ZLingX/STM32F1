#include <REGX52.H>
#include <INTRINS.H>
#include "Delay.h"

/*
在平时你如果嫌弃蜂鸣器乱叫，你可以手动把它关掉
Buzzer=0
*/

sbit Buzzer=P2^5;

void Buzzer_Delay250us()		//@12.000MHz
{
	unsigned char i;

	_nop_();
	i = 112;
	while (--i);
}

void Buzzer_Time(unsigned int ms)
{
	unsigned int i;
  for(i=0;i<ms*2;i++)
	{//由于Delay，不乘二就响半个ms（假设ms=1）
			Buzzer=!Buzzer;
			Buzzer_Delay250us(); 
	}
}

