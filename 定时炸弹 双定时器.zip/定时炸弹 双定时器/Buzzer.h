#ifndef __BUZZER_H_
#define __BUZZER_H_

void Buzzer_Time(unsigned int ms);
void Buzzer_ON();
void Buzzer_OFF();

#endif