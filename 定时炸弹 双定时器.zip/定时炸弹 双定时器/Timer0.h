#ifndef __TIMER0_H_
#define __TIMER0_H_

void Timer0_Init(void);

#endif
