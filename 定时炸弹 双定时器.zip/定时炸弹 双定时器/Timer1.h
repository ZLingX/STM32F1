#ifndef __Timer1_H_
#define __Timer1_H_

void Timer1();

#endif
