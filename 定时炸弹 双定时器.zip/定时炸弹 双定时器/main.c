#include <REGX52.H>
#include "Delay.h"
#include "Nixie.h"
#include "Buzzer.h"
#include "Timer0.h"
#include "Timer1.h"

/*
由于只用一个定时器存在主函数存在延时过长导致数码管消影子时间长而闪烁的问题
这里使用两个定时器
EA位是所有定时器的总开关
如EA=0,则所有定时器都停止工作，类比总闸
ET位是所有定时器的分开关
如ET0=0,则定时器0停止工作
如ET1=0,则定时器1停止工作，类比分闸
*/

sbit Buzzer=P2^5;

int Number1=30,Number2;/*秒数*/
int Flag1=0,Flag2=0;/*自定义标志位，0关闭，1开启*/
int T0Count_Nixie,T0Count_Buzzer1,T0Count_Buzzer2;/*用于计数*/

void main()
{
  Timer0_Init();/*定时器0和定时器1启动*/
	Timer1_Init();
	while(1)
	{ 
		/*********数码管********/
		Nixie(1,Number1/10);/*取十位*/
		Nixie(2,Number1%10);/*取个位*/
		/*********蜂鸣器*** ****/
		if(Flag1==1)/*标志位检测是否开启*/
		{
			ET1=1;/*打开定时器1，蜂鸣器开始鸣叫*/
			Flag2=1;/*Flag2标志位置1，打开蜂鸣器鸣叫时长计时计数*/
			if(Number1>20){Number2=20;}/*鸣叫频率限制*/
      else{Number2=Number1;}/*变量另外赋予*/
			T0Count_Buzzer1=Number2*100;/*50为自定义比例系数，比例控制蜂鸣器鸣叫时间*/
			Flag1=0;/*恢复标志位*/
		}
	}
}

void Timer0_Routine() interrupt 1/*1ms进入一次中断*/
{
	TL0 = 0x66;				/*设置定时初始值*/
	TH0 = 0xFC;				//设置定时初始值*/
	/****************计数**************/
	T0Count_Nixie++;/*数码管计数*/
	T0Count_Buzzer1--;/*蜂鸣器两次鸣叫之间的时间间隔的倒计时*/
	if(Flag2==1){T0Count_Buzzer2++;}
	/*用Flag2标志位判断蜂鸣器是否开始鸣叫，如果开始鸣叫了，则开始鸣叫时长计时计数*/
	/*************数码管显示***********/
	if(T0Count_Nixie>=1000)/*1s*/
	{
		T0Count_Nixie=0;
    Number1--;
		if(Number1<=0)Number1=0;
	}
	/*************蜂鸣器计数***********/
  if(T0Count_Buzzer1<=0)
  {Flag1=1;}
	
	if(T0Count_Buzzer2>=200)
	{
	  ET1=0;/*关闭Timer1，蜂鸣器停止鸣叫*/
		T0Count_Buzzer2=0;
		Flag2=0;
	}
}

/*Timer1只用于蜂鸣器鸣叫，控制Timer1开关控制蜂鸣器，避免了再主函数中使用蜂鸣器致使数码管闪烁*/
void Timer1_Routine() interrupt 3/*H1调*/
{
		TL1 = 65058%256;
		TH1 = 65058/256;
	  Buzzer=~Buzzer;
}
