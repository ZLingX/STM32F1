#include <REGX52.H>
#include "INTRINS.h"
#include "Timer1.h"

sbit ENA=P1^7;
sbit IN1=P1^6;
sbit IN2=P1^5;
sbit IN3=P1^4;
sbit IN4=P1^3;
sbit ENB=P1^2;
sbit L1=P3^3;
sbit L2=P3^4;
sbit M=P3^5;
sbit R2=P3^6;
sbit R1=P3^7;

unsigned char i,j,Count,Compare=35;
unsigned char PWMA,PWMB,Flag=0;

void PWM_Set(int a,int b)
{
	PWMA=a;
	PWMB=b;
}

void Car_Run_Stop(int a,int b)
{
  PWM_Set(a,b);
  IN1=0;
	IN2=0;
	IN3=0;
	IN4=0;
}

void Car_Run(int a,int b)
{
	PWM_Set(a,b);
  IN1=1;
	IN2=0;
	IN3=0;
	IN4=1;
}

void Car_Run_Neg(int a,int b)
{
	PWM_Set(a,b);
	IN1=0;
	IN2=1;
	IN3=1;
	IN4=0;
}

void Car_Turn_L(int a,int b)
{
	PWM_Set(a,b);
 	IN1=1;
	IN2=0;
	IN3=1;
	IN4=0;	
}

void Car_Turn_R(int a,int b)
{
  PWM_Set(a,b);
  IN1=0;
	IN2=1;
	IN3=0;
	IN4=1;
}

void Delay(unsigned int T)//500ms
{
	unsigned char i;
	i=227;
  while(T--)
	{
	while (--i);
	}
}

void Car_Init()
{
	Timer1_Init();
}

void Car_Go()
{
//	 if(Flag==0)
//	 {
//		 Car_Run(70,70);
//	 }
//	 
//	 if((M==1&&L2==1&&R2==1)||(M==0))
//	 {
//	   Flag=0;
//	 }
//		
//	 if(L2==0||R2==0)
//	 {
//		 Car_Run_Stop(0,0);
//		 Flag=1;
//	 }
//	 
//	 if(Flag==1)
//	 {
//		 if(L2==0||L1==0)
//		 {
//			 while(M==1)
//			 Car_Run(100,0);
//			 Flag=0;
//		 }

//		 
//		 if(R2==0||R1==0)
//		 {
//			 while(M==1)
//			 Car_Run(0,100);
//			 Flag=0;
//		 }
//	 }
	 
	 
	 if(Flag==0)
	 {
		 Car_Run(60,60);
	 }
	 
	 if((M==1&&L2==1&&R2==1)||(M==0))
	 {
	   Flag=0;
	 }
	 
	 if((M==0&&R2==0)||(M==0&&L2==0))
	 {
	   Flag=0;
	 }
		
	 if(L2==0||R2==0)
	 {
//		 Car_Run_Stop(0,0);
		 Flag=1;
	 }
	 
	 if(Flag==1)
	 {
		 if(L2==0||L1==0)
		 {
			 while(M==1)
			 Car_Turn_L(70,70);
			 Flag=0;
		 }

		 if(R2==0||R1==0)
		 {
			 while(M==1)
			 Car_Turn_R(70,70);
			 Flag=0;
		 }
	 }
}

void Timer1_Routine() interrupt 3
{
	TL1 = 0xA4;				//设置定时初始值
	TH1 = 0xFF;				//设置定时初始值
//L298N
	i++;
	j++;
	if(i>=100){i=0;}
	if(j>=100){j=0;}
	if(i<PWMA){ENA=1;}
	else {ENA=0;}
	if(j<PWMB){ENB=1;}
	else {ENB=0;}
}