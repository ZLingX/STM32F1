#include "sys.h" 
/*
TIM   GPIOA
TIM2  B6 B7  R
TIM4  A0 A1  L
*/
void Encoder_Init()
{
  MyENCODER_Init(RCC_APB1Periph_TIM2,RCC_APB2Periph_GPIOA,GPIO_Pin_0|GPIO_Pin_1,GPIOA,TIM2);
	MyENCODER_Init(RCC_APB1Periph_TIM4,RCC_APB2Periph_GPIOB,GPIO_Pin_6|GPIO_Pin_7,GPIOB,TIM4);
}

void Get_Speed(int* Encoder_L,int *Encoder_R)
{
  * Encoder_L=(short)TIM_GetCounter(TIM4);TIM_SetCounter(TIM4,0);
	* Encoder_R=(short)TIM_GetCounter(TIM2);TIM_SetCounter(TIM2,0);
}

/*
Speed=(float)(Encoder*200/390)//ÿ��
*/
