#ifndef __encoder_H_
#define __encoder_H_

#include "sys.h"

void Encoder_Init(void);
void Get_Speed(int* Encoder_L,int *Encoder_R);

#endif
