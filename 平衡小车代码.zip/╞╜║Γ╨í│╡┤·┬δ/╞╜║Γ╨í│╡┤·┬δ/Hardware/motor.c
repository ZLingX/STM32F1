#include "sys.h" 

/*
Motor 		GPIO_Pin   PWM
Motor_L   B12  B13   A8
Motor_R		B14  B15   A11
*/

//int Speed;

void Motor_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	MyPWM_Init(RCC_APB2Periph_TIM1,RCC_APB2Periph_GPIOA,GPIO_Pin_8|GPIO_Pin_11,GPIOA,TIM1,7200,1);
}

void SetSpeed(float motor_l,float motor_r)
{
	if(motor_l>=0)
	{
	 Ain2=1;
	 Ain1=0;
	 TIM_SetCompare1(TIM1,motor_l);
	}
	if(motor_r>0)
	{
	 Bin1=0;
	 Bin2=1;
	 TIM_SetCompare4(TIM1,motor_r);
	}
	
	
	if(motor_l<=0)
	{
	 Ain2=0;
	 Ain1=1;
	 TIM_SetCompare1(TIM1,-motor_l);
	}
	if(motor_r<=0)
	{
	 Bin1=1;
	 Bin2=0;
	 TIM_SetCompare4(TIM1,-motor_r);
	}
}

void LimitSpeed()
{
  if(Motor_L>=7000)Motor_L=Speed_Max;
	if(Motor_L<=-7000)Motor_L=Speed_Min;
	
	if(Motor_R>=7000)Motor_R=Speed_Max;
	if(Motor_R<=-7000)Motor_R=Speed_Min;
}

void Stop()
{
  if(Pitch>=70||Pitch<=-70)
	SetSpeed(0,0);
}

