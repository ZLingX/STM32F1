#ifndef __motor_H_
#define __motor_H_

#include "sys.h"

#define Ain2  PBout(12)
#define Ain1  PBout(13)
#define Bin1  PBout(14)
#define Bin2  PBout(15)
#define Speed_Max    7000
#define Speed_Min   -7000

void Motor_Init(void);
void SetSpeed(float motor_l,float motor_r);
void LimitSpeed(void);
void Stop(void);

#endif
