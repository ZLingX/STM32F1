#include "sys.h" 

/*
������������
1.MPU6050�ж�ģʽ���½��ؼ�⣬����ҪEXTI_Trigger_Falling

2.OLED�ļ����
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);//ʹ��B�˿�ʱ��
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
  ��ִ��MPU6050ʹ�ò���
	
3.ԭ��usart�Ĵ�����MPU6050DMP�йأ�����ת��sys
*/

uint8_t RxData;

int main(void)
{
	delay_init();/*delay����ִ��*/
//	OLED_Init();
//	OLED_Clear();
//	OLED_ShowCHinese(40,3,6);
//	OLED_ShowCHinese(56,3,7);
//	OLED_ShowCHinese(72,3,8);
	MPU_Init();
	mpu_dmp_init();
  MPU6050_MyEXTI_Init();
	Motor_Init();
	Encoder_Init();
	Serial_Init();
	
//	OLED_Clear();
//	OLED_ShowCHinese(0,0,0);
//	OLED_ShowCHinese(16,0,1);	
//	OLED_ShowChar(32,0,':',16);	
//	OLED_ShowCHinese(80,0,4);
//	
//	OLED_ShowCHinese(0,2,2);
//	OLED_ShowCHinese(16,2,1);
//	OLED_ShowChar(32,2,':',16);
//	OLED_ShowCHinese(88,2,5);

//	OLED_ShowCHinese(0,4,9);
//	OLED_ShowCHinese(16,4,10);
//	OLED_ShowCHinese(32,4,8);
//	OLED_ShowCHinese(48,4,11);
//	OLED_ShowChar(64,4,':',16);
//	OLED_ShowCHinese(112,4,5);

//	OLED_ShowCHinese(0,6,3);
//	OLED_ShowCHinese(16,6,1);
//	OLED_ShowChar(32,6,':',16);

	while (1)
	{	
		if(Serial_GetRxFlag()==1)
		{
			RxData = Serial_GetRxData();
			if(RxData==0x01){Target_Speed_Flag=1;}
		  else if(RxData==0x02){Target_Speed_Flag=-1;}
			else if(RxData==0x03){Target_Angle=40;}
			else if(RxData==0x04){Target_Angle=-40;}
			else if(RxData==0x00){Target_Speed_Flag=0;Target_Angle=0;Med_Angle=-0.2;}
		}
//		OLED_Float(40,0,Temperature,1,16);
//		OLED_Float(40,2,Pitch,1,16);
//		OLED_Float(80,4,Med_Angle,1,16);
//		OLED_Float(40,6,(float)(Encoder_L*200/390),1,16);
//		OLED_Float(80,6,(float)(Encoder_R*200/390),1,16);
	}
}

