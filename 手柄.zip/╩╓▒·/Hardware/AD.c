#include "stm32f10x.h"                  // Device header

void AD_Init()
{
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);
	//配置ADCCLK
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	//ADC专属模式
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
//	ADC_RegularChannelConfig(ADC1,ADC_Channel_0,1,ADC_SampleTime_55Cycles5);
	//选择规则组输入通道
	ADC_InitTypeDef ADC_InitStructure;
	//初始化ADC
	ADC_InitStructure.ADC_ContinuousConvMode=DISABLE;//ENABLE//连续
	//是否连续扫描
	ADC_InitStructure.ADC_DataAlign=ADC_DataAlign_Right;
	//左或右对齐
	ADC_InitStructure.ADC_ExternalTrigConv=ADC_ExternalTrigConv_None;
	//是否使用外部触发（ADC_ExternalTrigConv_None为内部软件触发）
	ADC_InitStructure.ADC_Mode=ADC_Mode_Independent;
	//ADC工作模式（单ADC或双ADC）
	ADC_InitStructure.ADC_NbrOfChannel=1;
	//扫描通道的个数（非扫描无需理会）
	ADC_InitStructure.ADC_ScanConvMode=DISABLE;
	//单通道（非扫描）或多通道（扫描）
	ADC_Init(ADC1,&ADC_InitStructure);
	ADC_Cmd(ADC1,ENABLE);
	/*以上为非连续*/
	
	/*以下为校准*/
	ADC_ResetCalibration(ADC1);
	while(ADC_GetResetCalibrationStatus(ADC1)==SET);
	ADC_StartCalibration(ADC1);
	while(ADC_GetCalibrationStatus(ADC1)==SET);
	
	/*若要连续，则ADC_SoftwareStartConvCmd(ADC1,ENABLE);只需触发一次即可*/
//	ADC_SoftwareStartConvCmd(ADC1,ENABLE);//连续
}

/*无DMA实现多通道需不断改变填充通道*/

uint16_t AD_GetValue(uint16_t ADC_Channel)//加入输入通道变量
{
	ADC_RegularChannelConfig(ADC1,ADC_Channel,1,ADC_SampleTime_55Cycles5);
	/*
	选择规则组输入通道置于此处
	ADC_Channel可取的值为
	ADC_Channel_0
	ADC_Channel_1
	ADC_Channel_2
	......
	*/
  ADC_SoftwareStartConvCmd(ADC1,ENABLE);//软件触发转换//连续无需
	while(ADC_GetFlagStatus(ADC1,ADC_FLAG_EOC)==RESET);//等待转换完成//连续无需
	return ADC_GetConversionValue(ADC1);//读取DR寄存器值并自动清除标志位
}
