#ifndef __Buzzer_H_
#define __Buzzer_H_

#include "sys.h"

void Buzzer_Init(void);
void Buzzer_ON(void);
void Buzzer_OFF(void);

#endif
