#include "sys.h"

int KeyNum=0,KeyNum1=0,KeyNum2=0,KeyNum3=0,KeyNum4=0;
int RxData,TxData,PS2LXData,PS2LYData,PS2LSWData,PS2RXData,PS2RYData,PS2RSWData,KEYData;
uint16_t ADValue0,ADValue1,ADValue2,ADValue3,ADValue4,ADValue5;
int Buzzer_Flag;

void OLED_ShowDataKinds()
{
	OLED_ShowString(0, 0,"AD0:",OLED_6X8);
	OLED_ShowString(0, 8,"AD1:",OLED_6X8);
	OLED_ShowString(0,16,"SW1:",OLED_6X8);
	OLED_ShowString(0,24,"AD3:",OLED_6X8);
	OLED_ShowString(0,32,"AD4:",OLED_6X8);
	OLED_ShowString(0,40,"SW2:",OLED_6X8);
//	OLED_ShowString(0,48,"KEY1:",OLED_6X8);	
//	OLED_ShowString(0,56,"KEY2:",OLED_6X8);	
//	OLED_ShowString(64,0,"KEY3:",OLED_6X8);
//	OLED_ShowString(64,8,"KEY4:",OLED_6X8);
	OLED_ShowString(64,0,"RX:",OLED_6X8);
	OLED_ShowString(64,8,"TX:",OLED_6X8);
	OLED_Update();
}

void OLED_ShowData()
{
    OLED_ShowNum(24, 0,ADValue0,4,OLED_6X8);
		OLED_ShowNum(24, 8,ADValue1,4,OLED_6X8);
		OLED_ShowNum(24,16,ADValue4,4,OLED_6X8);
		OLED_ShowNum(24,24,ADValue2,4,OLED_6X8);
		OLED_ShowNum(24,32,ADValue3,4,OLED_6X8);
		OLED_ShowNum(24,40,ADValue5,4,OLED_6X8);
		OLED_ShowNum(30,48,KeyNum,1,OLED_6X8);		
		OLED_ShowHexNum(82,0,RxData,2,OLED_6X8);
	  OLED_ShowHexNum(82,8,TxData,2,OLED_6X8);
		OLED_Update();
}

int main(void)
{
	Buzzer_Init();
	Key_Init();
	OLED_Init();
	MyUSART_Init(RCC_APB2Periph_GPIOA,GPIO_Pin_9,GPIO_Pin_10,GPIOA,RCC_APB2Periph_USART1,USART1,USART1_IRQn,1,1);
	MyTIM_Init(RCC_APB1Periph_TIM4,TIM4,7200,1000,TIM4_IRQn,1,0);
	AD_Init();
	OLED_Boot_Animation();
  OLED_ShowDataKinds();
	while (1)
	{
		/**********************************************************�����շ�����**********************************************************/
    if(ADValue0<=100){MyUSART_SendByte(USART1,0x01);TxData=0x01;}
		else if(ADValue0>=4000){MyUSART_SendByte(USART1,0x02);TxData=0x02;}
		else if(ADValue3<=100){MyUSART_SendByte(USART1,0x03);TxData=0x03;}
		else if(ADValue3>=4000){MyUSART_SendByte(USART1,0x04);TxData=0x04;}
		else {MyUSART_SendByte(USART1,0x00);TxData=0x00;}
		/**********************************************************��������**********************************************************/
		KeyNum=Key_GetNum();
		if(KeyNum){Buzzer_ON();delay2_ms(25);Buzzer_OFF();}//������Ч
		/**********************************************************oled��ʾ����**********************************************************/
		OLED_ShowData();
	}
}


void TIM4_IRQHandler()/*TIM4ÿ100ms�����ж�*/
{
	if(TIM_GetITStatus(TIM4,TIM_IT_Update)==SET)
	{
		
		ADValue0=AD_GetValue(ADC_Channel_0);
		ADValue1=AD_GetValue(ADC_Channel_1);
		ADValue2=AD_GetValue(ADC_Channel_2);
		ADValue3=AD_GetValue(ADC_Channel_3);
		ADValue4=AD_GetValue(ADC_Channel_4);
		ADValue5=AD_GetValue(ADC_Channel_5);
		
	}
  TIM_ClearITPendingBit(TIM4,TIM_IT_Update);
}


void USART1_IRQHandler()/*USART1*/
{
  if(USART_GetFlagStatus(USART1,USART_FLAG_RXNE)==SET)
  {
	  MyUSART_RxData=USART_ReceiveData(USART1);
    MyUSART_RxFlag=1;/*���ڱ�־λ��1*/
		/**********************************************************�����շ�����**********************************************************/
		if(MyUSART_GetRxFlag()==1)
		{ 
		  RxData=MyUSART_GetRxData();
		}
	  USART_ClearITPendingBit(USART1,USART_FLAG_RXNE);
  }
}

