#include <REGX52.H>

unsigned char Key_KeyNumber;

unsigned char key()
{
	unsigned char Temp=0;
	Temp=Key_KeyNumber;
	Key_KeyNumber=0;
  return Temp;
}

unsigned char Key_GetState()
{
	unsigned char KeyNumber=0;

	if(P3_2==0){KeyNumber=1;}
	if(P3_3==0){KeyNumber=2;}
	
	return KeyNumber;
}

void Key_Loop()
{
  static unsigned char NowState,LastState;
	
	LastState=NowState;
	NowState=Key_GetState();
	
	if(LastState==0 && NowState==1)
  {Key_KeyNumber=1;}
	if(LastState==0 && NowState==2)
  {Key_KeyNumber=2;}
}
