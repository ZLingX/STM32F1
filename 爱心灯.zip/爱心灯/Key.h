#ifndef __KEY_H__
#define __KEY_H__

unsigned char Key();
unsigned char Key_GetState();
void Key_Loop();

#endif
