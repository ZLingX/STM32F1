#include <REGX52.H>
#include "INTRINS.h"
#include "Timer0.h"
#include "Timer1.h"
#include "Key.h"
/**************************LED����**************************/
void LED_OFF()
{
  P0=0x00;
	P1=0x00;
	P2=0x00;
	P3=0x04|0x08;
}

void LED_ON()
{
  P0=0xFF;
	P1=0xFF;
	P2=0xFF;
	P3=0xFF;
}
/**************************��ʱ����**************************/

void Delay500ms()		//@11.0592MHz
{
	unsigned char i, j, k;

	_nop_();
	i = 4;
	j = 129;
	k = 119;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

void Delay50ms()		//@11.0592MHz
{
	unsigned char i, j;

	i = 90;
	j = 163;
	do
	{
		while (--j);
	} while (--i);
}

/**************************�������**************************/
unsigned int KeyNum,Flag=1;
int T0Count1,T0Count2,Step1=1,Step2=1,Compare=0;

void main()
{
	LED_OFF();
	Timer0_Init();
	Timer1_Init();
  while(1)
	{
		KeyNum=Key();
    if(KeyNum==1){Flag+=1;if(Flag>3)Flag=1;}
		if(KeyNum==2){Flag-=1;if(Flag<1)Flag=3;}
  }
}

void Timer0_Routine() interrupt 1
{
	TL0 = 0x66;				//���ö�ʱ��ʼֵ
	TH0 = 0xFC;				//���ö�ʱ��ʼֵ
	/********************ģʽһ********************/
	if(Flag==1)
	{
		LED_ON();
  }
	/********************ģʽ��********************/
	if(Flag==2)
  {
	  T0Count1++;
		if(T0Count1>=50)
		{
			T0Count1=0;
			Step1++;
			if(Step1>=16)Step1=1;
			if(Step1==1)
			{
			  P1_6=1;
				P1_5=1;
			}
			if(Step1==2)
			{
			  P1_7=1;
				P1_4=1;
				P1_6=0;
				P1_5=0;
			}
			if(Step1==3)
			{
			  P3_4=1;
				P1_3=1;
				P1_7=0;
				P1_4=0;
			}
			if(Step1==4)
			{
			  P3_5=1;
				P1_2=1;
				P3_4=0;
				P1_3=0;
			}
			if(Step1==5)
			{
			  P3_6=1;
				P1_1=1;
				P3_5=0;
				P1_2=0;
			}
			if(Step1==6)
			{
			  P3_7=1;
				P1_0=1;
				P3_6=0;
				P1_1=0;
			}
			if(Step1==7)
			{
			  P2_0=1;
				P0_0=1;
				P3_7=0;
				P1_0=0;
			}
			if(Step1==8)
			{
			  P2_1=1;
				P0_1=1;
				P2_0=0;
				P0_0=0;
			}
			if(Step1==9)
			{
			  P2_2=1;
				P0_2=1;
				P2_1=0;
				P0_1=0;
			}
			if(Step1==10)
			{
			  P2_3=1;
				P0_3=1;
				P2_2=0;
				P0_2=0;
			}
			if(Step1==11)
			{
			  P2_4=1;
				P0_4=1;
				P2_3=0;
				P0_3=0;
			}
			if(Step1==12)
			{
			  P2_5=1;
				P0_5=1;
				P2_4=0;
				P0_4=0;
			}
			if(Step1==13)
			{
			  P2_6=1;
				P0_6=1;
				P2_5=0;
				P0_5=0;
			}
			if(Step1==14)
			{
			  P2_7=1;
				P0_7=1;
				P2_6=0;
				P0_6=0;
			}
			if(Step1==15)
			{
			  P0=0;
				P1=0;
				P2=0;
				P3=0x04|0x08;
			}
		}
	}
  /********************ģʽ��********************/
	if(Flag==3)
  {
		T0Count1++;
		if(T0Count1>=50)
		{
			T0Count1=0;
			if(Step2==1)
      Compare++;
			if(Step2==2)
      Compare--;
			if(Compare>20)Step2=2;
			if(Compare< 0)Step2=1;
		}		
		T0Count2++;
		if(T0Count2>=20)T0Count2=0;
		if(T0Count2<Compare)
		{
	    LED_ON();
		}
		else LED_OFF();
	}  
}

void Timer1_Routine() interrupt 3
{
	static unsigned int T1Count;
	TL1 = 0x66;				//���ö�ʱ��ʼֵ
	TH1 = 0xFC;				//���ö�ʱ��ʼֵ
	T1Count++;
	if(T1Count>=30)
	{
		T1Count=0;
		Key_Loop();
	}
}
