#ifndef __BUZZER_H
#define __BUZZER_H
                

void BUZZER_Init(void);
void BUZZER_ON(void);
void BUZZER_OFF(void);
void BUZZER_Turn(void);



#endif
