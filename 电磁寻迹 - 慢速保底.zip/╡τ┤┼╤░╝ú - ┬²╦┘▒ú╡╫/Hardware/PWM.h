#ifndef __PWM_H
#define __PWM_H

void TIM1_PWM_Init(uint16_t ARR,uint16_t PSC);
void TIM1_PWM_Setcompare1(uint16_t Compare1);
void TIM1_PWM_Setcompare2(uint16_t Compare2);
void TIM1_PWM_Setcompare3(uint16_t Compare3);
void TIM1_PWM_Setcompare4(uint16_t Compare4);
void TIM2_PWM_Init(uint16_t ARR,uint16_t PSC);
void TIM2_PWM_Setcompare1(uint16_t Compare1);
void TIM2_PWM_Setcompare2(uint16_t Compare2);
void TIM2_PWM_Setcompare3(uint16_t Compare3);
void TIM2_PWM_Setcompare4(uint16_t Compare4);
void TIM3_PWM_Init(uint16_t ARR,uint16_t PSC);
void TIM3_PWM_Setcompare1(uint16_t Compare1);
void TIM3_PWM_Setcompare2(uint16_t Compare2);
void TIM3_PWM_Setcompare3(uint16_t Compare3);
void TIM3_PWM_Setcompare4(uint16_t Compare4);
void TIM4_PWM_Init(uint16_t ARR,uint16_t PSC);
void TIM4_PWM_Setcompare1(uint16_t Compare1);
void TIM4_PWM_Setcompare2(uint16_t Compare2);
void TIM4_PWM_Setcompare3(uint16_t Compare3);
void TIM4_PWM_Setcompare4(uint16_t Compare4);


#endif
