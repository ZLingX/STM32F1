#include "stm32f10x.h"                  // Device header
#include "sys.h"                  // Device header


void Servo_Init(void)
{
	TIM1_PWM_Init(10000,72);
}

void Servo_SetPWM(float Servo_PWM)
{
	TIM_SetCompare1(TIM1,Servo_PWM);
}
