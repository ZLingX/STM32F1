#ifndef __SERVO_H
#define __SERVO_H

void Servo_Init(void);
void Servo_SetPWM(float Servo_PWM);



#endif
