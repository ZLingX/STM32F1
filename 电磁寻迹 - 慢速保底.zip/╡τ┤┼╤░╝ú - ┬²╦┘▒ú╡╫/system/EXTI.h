#ifndef __EXTI_H
#define __EXTI_H

void EXTI0_NVIC_Init(uint8_t Preemtion,uint8_t Response);
void EXTI1_NVIC_Init(uint8_t Preemtion,uint8_t Response);
void EXTI2_NVIC_Init(uint8_t Preemtion,uint8_t Response);
void EXTI3_NVIC_Init(uint8_t Preemtion,uint8_t Response);
void EXTI4_NVIC_Init(uint8_t Preemtion,uint8_t Response);
void EXTI5_9_NVIC_Init(uint8_t Preemtion,uint8_t Response);
void EXTI10_15_NVIC_Init(uint8_t Preemtion,uint8_t Response);

#endif
