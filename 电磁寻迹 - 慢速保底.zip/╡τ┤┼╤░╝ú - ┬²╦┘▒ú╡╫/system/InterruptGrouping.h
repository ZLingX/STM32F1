#ifndef __INTERRUPTGROUPING_H
#define __INTERRUPTGROUPING_H

void NVIC_Config(void);


#endif
