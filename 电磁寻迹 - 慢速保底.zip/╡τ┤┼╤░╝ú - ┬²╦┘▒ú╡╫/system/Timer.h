#ifndef __TIMER_H
#define __TIMER_H

void TIM1_Base_Init(uint16_t ARR,uint16_t PSC);
void TIM1_NVIC_Init(uint8_t Preemtion,uint8_t Response);
void TIM2_Base_Init(uint16_t ARR,uint16_t PSC);
void TIM2_NVIC_Init(uint8_t Preemtion,uint8_t Response);
void TIM3_Base_Init(uint16_t ARR,uint16_t PSC);
void TIM3_NVIC_Init(uint8_t Preemtion,uint8_t Response);
void TIM4_Base_Init(uint16_t ARR,uint16_t PSC);
void TIM4_NVIC_Init(uint8_t Preemtion,uint8_t Response);

#endif
