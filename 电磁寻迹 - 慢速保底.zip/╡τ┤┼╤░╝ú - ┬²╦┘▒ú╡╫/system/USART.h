#ifndef __USART_H
#define __USART_H

#include "stdio.h"                  


extern uint8_t USART_TxPacket[];
extern uint8_t USART_RxPacket[];
extern uint16_t Num;


void USART1_Init(uint32_t BaudRate);
void USART1_NVIC_Init(uint8_t Preemtion,uint8_t Response);
void USART_SendByte(uint8_t Byte);
void USART_SendArray(uint8_t *Array,uint16_t Length);
void USART_SendString(char *String);
void USART_SendNumber(uint32_t Number,uint8_t Length);
void USART_printf(char *format,...);
void USART_SendPacket(void);
uint8_t USART_GetRxFlag(void);
int16_t Data_Process(uint8_t HSB,uint8_t LSB);//��������Ԥ�����������ɽ�������



#endif
