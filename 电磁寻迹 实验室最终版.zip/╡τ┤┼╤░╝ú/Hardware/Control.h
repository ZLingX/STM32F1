#ifndef __CONTROL_H
#define __CONTROL_H

void Limit(int16_t *pwm);
void Limit_Servo(double *pwm);
float ChaBiHe_X1(void);
float ChaBiHe_X2(void);
float ChaBiHe_Y(void);




#endif
