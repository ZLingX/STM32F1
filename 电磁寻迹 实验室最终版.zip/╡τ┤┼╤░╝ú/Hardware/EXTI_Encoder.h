#ifndef __EXTI_ENCODER_H
#define __EXTI_ENCODER_H

void Encode_Init(void);
int16_t Encoder_Get(void);


#endif
