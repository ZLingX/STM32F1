#ifndef __GHG_H
#define __GHG_H

void GHG_Init(void);

#endif


