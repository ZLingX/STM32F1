#include "stm32f10x.h"                  // Device header

int16_t TargetB,TargetA;

