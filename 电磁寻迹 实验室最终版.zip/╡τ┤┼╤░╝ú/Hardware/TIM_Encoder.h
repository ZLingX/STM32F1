#ifndef __TIM_ENCODER_H
#define __TIM_ENCODER_H

void TIM1_Encoder_Init(uint16_t ARR,uint16_t PSC);
void TIM2_Encoder_Init(uint16_t ARR,uint16_t PSC);
void TIM3_Encoder_Init(uint16_t ARR,uint16_t PSC);
void TIM4_Encoder_Init(uint16_t ARR,uint16_t PSC);
int16_t TIM1_Encoder_Get(void);
int16_t TIM2_Encoder_Get(void);
int16_t TIM3_Encoder_Get(void);
int16_t TIM4_Encoder_Get(void);


#endif
