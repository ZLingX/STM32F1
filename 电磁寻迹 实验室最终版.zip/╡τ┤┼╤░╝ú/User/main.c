#include "sys.h"                  // Device header

uint8_t KeyNum;
float  state_Flag=0;
float error_x,error_y,speed_k=0.51;
int16_t t=2200;

int main(void)
{
	delay_init();
	OLED_Init();
	OLED_Clear();
	USART1_Init(9600);
	TIM2_Base_Init(10000-1,72-1);
	AD_Init();
	BUZZER_Init();
	GHG_Init();
	Servo_Init();
	Key_Init();
	Servo_SetPWM(PWM_ServoCenten);
	Motor_Init();
	TIM3_Encoder_Init(65536-1,1-1);
	NVIC_Config();
    EXTI->IMR&=~(EXTI_Line1);//��ʼ���رռ������ߵ��ж�
	while(1)
	{   

		KeyNum=Key_GetNum();
		if(KeyNum==1)
		{
			Input_Speed+=0.3;
		}
		if(KeyNum==2)
		{
			speed_k-=0.02;
		}
//		if(KeyNum==3)
//		{
//			t-=100;
//		}
//		OLED_ShowNum(0,0,AD_valu[5],4,16);
//		OLED_ShowNum(40,0,AD_valu[4],4,16);
//		OLED_ShowNum(80,0,AD_valu[3],4,16);		
//		OLED_ShowNum(0,2,AD_valu[2],4,16);
//		OLED_ShowNum(40,2,AD_valu[1],4,16);
//		OLED_ShowNum(80,2,AD_valu[0],4,16);
        OLED_Showdecimal(0,0,Input_Speed,9,16);
		OLED_Showdecimal(0,2,speed_k,9,16);
//	    OLED_Showdecimal(0,4,t,9,16);
			if((AD_valu[3]-AD_valu[2])<-180)//�����������
		{
//			ChaBiHe=0.5*ChaBiHe_X1()+1.0*ChaBiHe_Y();
			error_x=0.5;
			error_y=0.8;
			BUZZER_ON();
		}
		   else if((AD_valu[3]-AD_valu[2])>180)
		{
			error_x=1.0;
			error_y=1.2;
			BUZZER_ON();
		}
		  else
		{
//			ChaBiHe=error_x*ChaBiHe_Y()+error_y*ChaBiHe_X1();
			error_x=0.6;
			error_y=0.3;
			BUZZER_OFF();
		}
		Target_Speed=Input_Speed-speed_k*Input_Speed*fabs(Servo_PWM-PWM_ServoCenten)/500;
	}
         
}





