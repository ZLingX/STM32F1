#ifndef __control_H_
#define __control_H_

#include "sys.h"

void Control_Init(void);

//float Vertical(float Med,float Angle,float Gyro_Y);
//float Velocity(int Target,int encoder_left,int encoder_right);
//float Turn(float Target,float encoder_left,float encoder_right,float Gyro_Z);

#endif
