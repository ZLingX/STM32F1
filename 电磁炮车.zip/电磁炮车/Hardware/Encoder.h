#ifndef __Encoder_H_
#define __Encoder_H_

void Encoder_Init(void);

#endif
