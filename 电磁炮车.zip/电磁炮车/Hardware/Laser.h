#ifndef __Laser_H_
#define __Laser_H_

#include "sys.h"

void Laser_Init(void);
void Laser_ON(void);
void Laser_OFF(void);

#endif
