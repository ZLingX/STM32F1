#include "sys.h" 

int Motor_L,Motor_R;
int Speed_L,Speed_R;

void Motor_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	MyPWM_Init(RCC_APB1Periph_TIM2,RCC_APB2Periph_GPIOA,GPIO_Pin_0|GPIO_Pin_1,GPIOA,TIM2,7200,1);
}

void SetSpeed(float motor_l,float motor_r)
{
	if(motor_l>=0)
	{
	 Ain2=1;
	 Ain1=0;
	 TIM_SetCompare1(TIM2,motor_l);
	}
	if(motor_r>0)
	{
	 Bin1=0;
	 Bin2=1;
	 TIM_SetCompare2(TIM2,motor_r);
	}
	
	
	if(motor_l<=0)
	{
	 Ain2=0;
	 Ain1=1;
	 TIM_SetCompare1(TIM2,-motor_l);
	}
	if(motor_r<=0)
	{
	 Bin1=1;
	 Bin2=0;
	 TIM_SetCompare2(TIM2,-motor_r);
	}
}

void Get_Speed()
{
  Speed_L=Encoder_L;
	Speed_R=Encoder_R;
	Encoder_L=0;Encoder_R=0;
}

void LimitSpeed()
{
  if(Motor_L>=7000)Motor_L=Speed_Max;
	if(Motor_L<=-7000)Motor_L=Speed_Min;
	
	if(Motor_R>=7000)Motor_R=Speed_Max;
	if(Motor_R<=-7000)Motor_R=Speed_Min;
}

void Stop()
{
	SetSpeed(0,0);
}

