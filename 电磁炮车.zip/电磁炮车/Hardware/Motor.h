#ifndef __motor_H_
#define __motor_H_

#include "sys.h"

#define Ain2  PAout(7)
#define Ain1  PAout(6)
#define Bin1  PAout(5)
#define Bin2  PAout(4)
#define Speed_Max    7000
#define Speed_Min   -7000

void Motor_Init(void);
void SetSpeed(float motor_l,float motor_r);
void Get_Speed(void);
void LimitSpeed(void);
void Stop(void);

#endif
