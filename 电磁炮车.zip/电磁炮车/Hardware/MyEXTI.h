#ifndef __MyEXTI_H_
#define __MyEXTI_H_

#include "Sys.h"                  // Device header

/*����Ҫ����жϣ����ں����������Ӻ�׺*/
void MyEXTI_Init(
/*GPIO*/
uint32_t RCC_APB2Periph_GPIOX,/* RCC_APB2Periph_GPIOA RCC_APB2Periph_GPIOB ... */
uint16_t GPIO_Pin_X,/* GPIO_Pin_Number From 0 to ... ����"|" */
GPIO_TypeDef * GPIOX,/*GPIO��ʼ��*/
/*���Ź���ģʽ���ٶ�����*/

/*AFIO*/
uint8_t GPIO_PortSourceGPIOX,/* GPIO_PortSourceGPIOA GPIO_PortSourceGPIOB */
uint8_t GPIO_PinSourceX,/* GPIO_PinSourceNumber From 0 to ... ��Pin��Ӧ */

/*EXTI*/
uint32_t EXTI_LineX,/* EXTI_LineNumber From 0 to ... ��Pin��Ӧ */
/*�ж�ģʽ�ʹ�����ʽ����*/

/*NVIC*/
uint8_t EXTIX_IRQn,/* EXTI0_IRQn~EXTI8_IRQn EXTI9_5_IRQn EXTI15_10_IRQn*/
uint8_t PreemptionPriority,/*According to the NVIC_PriorityGroup*/
uint8_t SubPriority/*According to the NVIC_PriorityGroup*/
);

#endif

/*
�ж����޸���
GPIOX
GPIO_Pin_X
EXTI_LineX
*/

/**********************�ⲿ�ж�ͨ��0������**********************/
//void EXTI0_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line0);
//}

/**********************�ⲿ�ж�ͨ��1������**********************/
//void EXTI1_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line1);
//}

/**********************�ⲿ�ж�ͨ��2������**********************/
//void EXTI2_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_2) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line2);
//}

/**********************�ⲿ�ж�ͨ��3������**********************/
//void EXTI3_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line3);
//}

/**********************�ⲿ�ж�ͨ��4������**********************/
//void EXTI4_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line4);
//}

/**********************�ⲿ�ж�ͨ��5-9������**********************/
//void EXTI9_5_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line5);
//}

//void EXTI9_5_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line6);
//}

//void EXTI9_5_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line6);
//}

//void EXTI9_5_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line7);
//}

//void EXTI9_5_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line8);
//}

//void EXTI9_5_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line9);
//}

/**********************�ⲿ�ж�ͨ��10-15������****************/
//void EXTI15_10_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_10) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line10);
//}

//void EXTI15_10_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line11);
//}

//void EXTI15_10_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line12);
//}

//void EXTI15_10_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line13);
//}

//void EXTI15_10_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line14);
//}

//void EXTI15_10_IRQHandler(void)
//{
//	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_15) == 0)
//		{
//			
//		}
//		EXTI_ClearITPendingBit(EXTI_Line15);
//}

/*
 The table below gives the allowed values of the pre-emption priority and subpriority according
 to the Priority Grouping configuration performed by NVIC_PriorityGroupConfig function
  ============================================================================================================================
    NVIC_PriorityGroup   | NVIC_IRQChannelPreemptionPriority | NVIC_IRQChannelSubPriority  | Description
  ============================================================================================================================
   NVIC_PriorityGroup_0  |                0                  |            0-15             |   0 bits for pre-emption priority
                         |                                   |                             |   4 bits for subpriority
  ----------------------------------------------------------------------------------------------------------------------------
   NVIC_PriorityGroup_1  |                0-1                |            0-7              |   1 bits for pre-emption priority
                         |                                   |                             |   3 bits for subpriority
  ----------------------------------------------------------------------------------------------------------------------------    
   NVIC_PriorityGroup_2  |                0-3                |            0-3              |   2 bits for pre-emption priority
                         |                                   |                             |   2 bits for subpriority
  ----------------------------------------------------------------------------------------------------------------------------    
   NVIC_PriorityGroup_3  |                0-7                |            0-1              |   3 bits for pre-emption priority
                         |                                   |                             |   1 bits for subpriority
  ----------------------------------------------------------------------------------------------------------------------------    
   NVIC_PriorityGroup_4  |                0-15               |            0                |   4 bits for pre-emption priority
                         |                                   |                             |   0 bits for subpriority                       
  ============================================================================================================================
*/
