#include "sys.h"                  // Device header

int RailGun_Count=0,Launch_Flag=0,Fire=0;
extern int AD;

extern int Mode_Flag,KeyNum;
extern uint16_t Horizontal_axis,Longotudinal_axis;

void RailGun_Init()
{
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	MyAD_Init(RCC_APB2Periph_ADC3,RCC_APB2Periph_GPIOC,GPIO_Pin_0,GPIOC,ADC_ExternalTrigConv_None,ENABLE,DISABLE,1,ADC3);
	/*AD_GetValue(ADC3,1);*/
	
	GPIO_ResetBits(GPIOC,GPIO_Pin_1);
	GPIO_ResetBits(GPIOC,GPIO_Pin_2);
}

void RailGun_Delay(int Count)
{
	while(RailGun_Count<Count)
	{
			OLED_ShowNum(0,0,Mode_Flag,4,OLED_6X8);	
			OLED_ShowNum(0,8,Horizontal_axis,4,OLED_6X8);
			OLED_ShowNum(0,16,Longotudinal_axis,4,OLED_6X8);	
		  OLED_ShowNum(0,24,KeyNum,4,OLED_6X8);
		  OLED_ShowNum(0,32,Launch_Flag,4,OLED_6X8);
		  OLED_ShowNum(0,40,RailGun_Count,4,OLED_6X8);
			OLED_Update();
		
	}
	RailGun_Count=0;
}

void StartCharge()
{
  GPIO_SetBits(GPIOC,GPIO_Pin_1);
}

void StopCharge()
{
  GPIO_ResetBits(GPIOC,GPIO_Pin_1);
}

void Charge()
{
  StartCharge();
	RailGun_Delay(100);
	StopCharge();
}

void Launch()
{
  GPIO_SetBits(GPIOC,GPIO_Pin_2);
	RailGun_Delay(5);
	GPIO_ResetBits(GPIOC,GPIO_Pin_2);
}

void DirectLaunch()
{
	Buzzer_ON();
	Fire=1;
  Charge();
	RailGun_Delay(25);
	Launch();
	Buzzer_OFF();
	Fire=0;
}
