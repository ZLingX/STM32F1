#ifndef __RailGun_H_
#define __RailGun_H_

#include "sys.h"

void RailGun_Init(void);
void StartCharge(void);
void StopCharge(void);
void Charge(void);
void Launch(void);
void DirectLaunch(void);

#endif
