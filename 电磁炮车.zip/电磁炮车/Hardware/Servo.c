#include "sys.h" 

void Servo_Init()
{
  MyPWM_Init(RCC_APB1Periph_TIM4,RCC_APB2Periph_GPIOB,GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8,GPIOB,TIM4,20000,72);
}

void Set_MotorAngle(int angle) /*С��ת����*/
{
	if(angle>=2200){angle=2200;}
	if(angle<=1000){angle=1000;}
	TIM_SetCompare1(TIM4,angle);
}

void Set_RailGunAngle1(int angle) /*�����̧����*/
{
	if(angle>=2000){angle=2000;}
	if(angle<=1000){angle=1000;}
	TIM_SetCompare2(TIM4,angle);
}

void Set_RailGunAngle2(int angle) /*�����ת����*/
{
	if(angle>=2500){angle=2500;}
	if(angle<=500){angle=500;}
	TIM_SetCompare3(TIM4,angle);
}

void Set_UltrasonicAngle(int angle) /*������ת����*/
{
	if(angle>=2500){angle=2500;}
	if(angle<=500){angle=500;}
	TIM_SetCompare4(TIM4,angle);
}
