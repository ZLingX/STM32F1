#include "sys.h"                  // Device header

uint16_t Distance;

void HC_SR04_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	
	GPIO_InitTypeDef  GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;	 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(GPIOC, &GPIO_InitStructure);
 
	GPIO_ResetBits(GPIOC,GPIO_Pin_0);
//	GPIO_ResetBits(GPIOA,GPIO_Pin_1);
//	MyTIM_Init(RCC_APB1Periph_TIM7,TIM7,7200,1,TIM7_IRQn,1,0);/*100us*/
}

void HC_SR04_Start()
{
	GPIO_SetBits(GPIOC,GPIO_Pin_3);
	Delay_us(45);
	GPIO_ResetBits(GPIOC,GPIO_Pin_3);
	Distance=0;
}

uint16_t HCSR04_Get_Data()
{
	HC_SR04_Start();
	Delay_ms(100);
	return ((Distance * 0.0001) * 34000) / 2;
}

//void TIM7_IRQHandler()/*100us*/
//{
//	if(TIM_GetITStatus(TIM7,TIM_IT_Update)==SET)
//	{ 
//    if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)==1){Distance++;}
//	}
//  TIM_ClearITPendingBit(TIM7,TIM_IT_Update);
//}
