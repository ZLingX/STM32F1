#include "sys.h"

int Mode_Flag=0,KeyNum=1;

int AD,Motor_Speed,MotorAngle,GunAngle1=1300/*1300*/,GunAngle2=1580/*1580*/;

uint16_t Horizontal_axis,Longotudinal_axis;

void OLED_ShowData()
{
	OLED_ShowNum(0,0,Mode_Flag,4,OLED_6X8);	
	OLED_ShowNum(0,8,Horizontal_axis,4,OLED_6X8);
	OLED_ShowNum(0,16,Longotudinal_axis,4,OLED_6X8);	
	OLED_ShowNum(0,24,KeyNum,4,OLED_6X8);
	OLED_ShowNum(0,32,Launch_Flag,4,OLED_6X8);
	OLED_ShowNum(0,40,RailGun_Count,4,OLED_6X8);
	OLED_Update();
}

void NRF24L01Buf_Caculate()
{
  Horizontal_axis=(uint16_t)((NRF24L01Buf[0]<<8)+NRF24L01Buf[1]);
  Longotudinal_axis=(uint16_t)((NRF24L01Buf[2]<<8)+NRF24L01Buf[3]);
	KeyNum=(uint16_t)(NRF24L01Buf[4]);
	
//		OLED_ShowNum(0,0,(uint16_t)((NRF24L01Buf[0]<<8)+NRF24L01Buf[1]),4,OLED_6X8);
//		OLED_ShowNum(0,8,(uint16_t)((NRF24L01Buf[2]<<8)+NRF24L01Buf[3]),4,OLED_6X8);
//		OLED_ShowNum(0,16,(uint16_t)((NRF24L01Buf[4]<<8)+NRF24L01Buf[5]),4,OLED_6X8);
//		OLED_ShowNum(0,24,(uint16_t)((NRF24L01Buf[6]<<8)+NRF24L01Buf[7]),4,OLED_6X8);
//		OLED_ShowNum(0,32,(uint16_t)((NRF24L01Buf[8]<<8)+NRF24L01Buf[9]),4,OLED_6X8);
//		OLED_ShowNum(0,40,(uint16_t)((NRF24L01Buf[10]<<8)+NRF24L01Buf[11]),4,OLED_6X8);
}

int main(void)
{
  CloseJTAGMode();
	
	/*OLED*/
	OLED_Init();
	
	/*������*/
	Buzzer_Init();
	
	/*����*/
	Laser_Init();
	
	/*����ڵ�ѹ���ƶ�*/
	RailGun_Init();
	


	/*��������*/
//	MyUSART_Init(RCC_APB2Periph_GPIOC,GPIO_Pin_10,GPIO_Pin_11,GPIOC,RCC_APB1Periph_UART4,UART4,UART4_IRQn,0,3);
	
	/*NRF24L01*/
	NRF24L01_Init();
	
	/*Motor�������*/
	Motor_Init();
	
	
//	/*Encoder�жϲ���*/
//	Encoder_Init();

  /*Servo��·���*/
	Servo_Init();


//	/*������*/
//	HC_SR04_Init();

//	/*MPU050*/
//	MPU6050_Init();
//	MPU6050_DMP_Init();

   OLED_Boot_Animation();

  /*������ʱ��6*/
	MyTIM_Init(RCC_APB1Periph_TIM6,TIM6,720,2000,TIM6_IRQn,0,0);/*20ms*/
  MyTIM_Init(RCC_APB1Periph_TIM7,TIM7,720,1000,TIM7_IRQn,0,0);/*10ms*/
	
	
	while (1)
	{
		/*NRF24L01���ݴ��亯��*/
		if(R_IRQ()==0)
		{
			Receive(NRF24L01Buf);
		}
		
		if(KeyNum==1){Mode_Flag=0;}
		if(KeyNum==2){Mode_Flag=1;}
		if(KeyNum==3){Buzzer_ON();Delay_ms(200);Buzzer_OFF();}
		
		if(Mode_Flag==0){Laser_OFF();Launch_Flag=0;}
		if(Mode_Flag==1)Laser_ON();
		
		if(KeyNum==4)Launch_Flag++;
		if(Launch_Flag>3)
		{
			DirectLaunch();
			Launch_Flag=0;
		}
		
//		AD=AD_GetValue(ADC3,ADC_Channel_10);
//		OLED_ShowNum(0,16,AD,4,OLED_8X16);
		
		OLED_ShowData();

	}
}

/*��ʱ��6��ʱ�жϺ���*/
void TIM6_IRQHandler()
{
	if(TIM_GetITStatus(TIM6,TIM_IT_Update)==SET)
	{ 
		
    NRF24L01Buf_Caculate();
		
		if(Mode_Flag==0)/*С���ƶ�ģʽ*/
		{
			Motor_Speed=(2048-Horizontal_axis)*2;
//			MotorAngle=1560+(Longotudinal_axis-2085)/5;
			
			if(Longotudinal_axis>=4000){MotorAngle+=20;if(MotorAngle>=2200){MotorAngle=2200;}}
			else if(Longotudinal_axis<=0){MotorAngle-=20;if(MotorAngle<=1100){MotorAngle=1100;}} 
			else if(Longotudinal_axis>1||Longotudinal_axis<3999)
			{
			  if(MotorAngle>1580)MotorAngle-=20;
				if(MotorAngle<1580)MotorAngle+=20;
			}
		}
		
		if(Mode_Flag==1)/*�����ģʽ*/
		{
			if(Horizontal_axis<=0){GunAngle1+=2;if(GunAngle1>=2000){GunAngle1=2000;}}
			if(Horizontal_axis>=4000){GunAngle1-=2;if(GunAngle1<=1000){GunAngle1=1000;}}
			if(Longotudinal_axis<=0){GunAngle2+=2;	if(GunAngle2>=2500){GunAngle2=2500;}}
			if(Longotudinal_axis>=4000){GunAngle2-=2;if(GunAngle2<=500){GunAngle2=500;}}
		}
		
		if(Mode_Flag==1)/*�����ģʽ*/
	 {  
		 if(Fire)
			RailGun_Count++;
	 }
		TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
	}
}

void TIM7_IRQHandler()
{
	if(TIM_GetITStatus(TIM7,TIM_IT_Update)==SET)
	{ 	
		if(Mode_Flag==0)/*С���ƶ�ģʽ*/
		{
			SetSpeed(Motor_Speed,Motor_Speed);
			Set_MotorAngle(MotorAngle);
		}
		
		if(Mode_Flag==1)/*�����ģʽ*/
		{		
			Set_RailGunAngle1(GunAngle1);
			Set_RailGunAngle2(GunAngle2);
		}
		TIM_ClearITPendingBit(TIM7,TIM_IT_Update);
	}
}

///*���������жϷ���ͨ��*/
//void UART4_IRQHandler()
//{
//  if(USART_GetFlagStatus(UART4,USART_FLAG_RXNE)==SET)
//  {
//    USART_ClearITPendingBit(UART4,USART_FLAG_RXNE);
//    MyUSART_RxData=USART_ReceiveData(UART4);
//  }
//}

//		OLED_ShowNum(0,0,MyUSART_RxData,2,OLED_8X16);
