 /**********************************************************************************
********************* ������ͨ��ѧ �����ͨѧԺ �������ʵ����*********************
***********************************************************************************
 * ����         �����ܳ����Ƴ���  ����CCD+�������+1602LCD��ʾ
 *
 * ʵ��ƽ̨     ���������XS128ϵͳ�� + TSL1401����CCD������
 *
 * ����         ���ƽ���
**********************************************************************************/
/*
*********************************************************************************************************
*
*                                      MCU: MC9S12XS128MAL - 112Pin
*                                      OSC: 16.000MHz
*                                      BUS: 40.0MHz
*
* File : main.c
* By   : Ke Chao
*********************************************************************************************************
*/ 
  
 #include "includes.h"
 
 
                                    
 void speed_adjust(void) 
 
{



if(!PORTB_PB0)       
{                                                     //�ٶ�ѡ��
  speed_zhi=35;
  speed_wan=30;
  speed_slow=25;
}
                                           
else if(!PORTB_PB1)   
{
  speed_zhi=38;
  speed_wan=33;
  speed_slow=28;
}

else if(!PORTB_PB2)   
{
  speed_zhi=40;
  speed_wan=35;
  speed_slow=30;
}
else if(!PORTB_PB3)   
{
  speed_zhi=45;
  speed_wan=35;
  speed_slow=32;
}

else if(!PORTB_PB4)       
{
  speed_zhi=speed_wan=speed_slow=30;
}
else if(!PORTB_PB5)  
{
  speed_zhi=speed_wan=speed_slow=35;
}
else if(!PORTB_PB5)  
{
  speed_zhi=speed_wan=speed_slow=40;
}
else                 
{
  speed_zhi=speed_wan=speed_slow=30;
} 




if(!PORTB_PB7)       stop_c=1;
else                 stop_c=0;    
 
 
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 