 /**********************************************************************************
********************* ������ͨ��ѧ �����ͨѧԺ �������ʵ����*********************
***********************************************************************************
 * ����         �����ܳ����Ƴ���  ����CCD+�������+1602LCD��ʾ
 *
 * ʵ��ƽ̨     ���������XS128ϵͳ�� + TSL1401����CCD������
 *
 * ����         ���ƽ���
**********************************************************************************/
/*
*********************************************************************************************************
*
*                                      MCU: MC9S12XS128MAL - 112Pin
*                                      OSC: 16.000MHz
*                                      BUS: 40.0MHz
*
* File : main.c
* By   : Ke Chao
*********************************************************************************************************
*/ 
  
 #include "includes.h"
 
 
                                    
 void speed_adjust(void) 
 
{



if(!PORTB_PB0)       
{                                                     //�ٶ�ѡ��
  speed_zhi=35;
  speed_wan=29;
  speed_slow=24;
}
                                           
else if(!PORTB_PB1)   
{
  speed_zhi=38;
  speed_wan=32;
  speed_slow=27;
}

else if(!PORTB_PB2)   
{
   speed_zhi=42;
  speed_wan=36;
  speed_slow=31;
}
else if(!PORTB_PB3)   
{
  speed_zhi=44;
  speed_wan=37;
  speed_slow=33;
}

else if(!PORTB_PB4)       
{
  speed_zhi=46;
  speed_wan=39;
  speed_slow=35;
}
else if(!PORTB_PB5)  
{
  speed_zhi=45;
  speed_wan=40;
  speed_slow=35;
}
else                 
{
  speed_zhi=speed_wan=speed_slow=30;
} 





if(!PORTB_PB6)
{
ren_c=1;
LED6=0;
}  
else 
{
ren_c=0;

}

if(!PORTB_PB7)       
{
stop_c=1;
LED7=0;
}
else                 
{
stop_c=0;    
} 
 
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 