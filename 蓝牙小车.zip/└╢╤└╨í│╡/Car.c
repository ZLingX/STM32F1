#include <REGX52.H>
#include "INTRINS.h"
#include "Timer1.h"
#include "UART.h"

sbit ENA=P1^7;
sbit IN1=P1^6;
sbit IN2=P1^5;
sbit IN3=P1^4;
sbit IN4=P1^3;
sbit ENB=P1^2;

unsigned char i,j,Count,Compare=35;
unsigned char PWMA,PWMB,Lab=4,Data;

void PWM_Set(int a,int b)
{
	PWMA=a;
	PWMB=b;
}

void Car_Run_Stop(int a,int b)
{
  PWM_Set(a,b);
  IN1=0;
	IN2=0;
	IN3=0;
	IN4=0;
}

void Car_Run(int a,int b)
{
	PWM_Set(a,b);
  IN1=1;
	IN2=0;
	IN3=0;
	IN4=1;
}

void Car_Run_Neg(int a,int b)
{
	PWM_Set(a,b);
	IN1=0;
	IN2=1;
	IN3=1;
	IN4=0;
}

void Car_Turn_L(int a,int b)
{
	PWM_Set(a,b);
 	IN1=1;
	IN2=0;
	IN3=1;
	IN4=0;	
}

void Car_Turn_R(int a,int b)
{
  PWM_Set(a,b);
  IN1=0;
	IN2=1;
	IN3=0;
	IN4=1;
}

void Delay(unsigned int T)//500ms
{
	unsigned char i;
	i=227;
  while(T--)
	{
	while (--i);
	}
}

void Car_Init()
{
	Timer1_Init();
	URAT_Init();
}

void Car_Go()
{ 
	if(Lab==0){Car_Run(70,70);}
	if(Lab==1){Car_Run_Neg(70,70);}
	if(Lab==2){Car_Turn_L(70,70);}
	if(Lab==3){Car_Turn_R(70,70);}
	if(Lab==4){Car_Run_Stop(0,0);}
}

void Timer1_Routine() interrupt 3
{
	TL1 = 0xA4;				//设置定时初始值
	TH1 = 0xFF;				//设置定时初始值
//L298N
	i++;
	j++;
	if(i>=100){i=0;}
	if(j>=100){j=0;}
	if(i<PWMA){ENA=1;}
	else {ENA=0;}
	if(j<PWMB){ENB=1;}
	else {ENB=0;}
}

void UART_Routine() interrupt 4//串口中断
{
		RI=0;
	
		Data=SBUF;						//发送的数据SBUF赋给Data
		if(Data==0x00){Lab=0;}
		if(Data==0x01){Lab=1;}
		if(Data==0x02){Lab=2;}
		if(Data==0x03){Lab=3;}
		if(Data==0x04){Lab=4;}
}