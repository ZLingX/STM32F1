#ifndef __UART_H_
#define UART_H_

void URAT_Init();

#endif