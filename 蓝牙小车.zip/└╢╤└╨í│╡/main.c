#include <REGX52.H>
#include "Car.h"

void main()
{
  Car_Init();
  while(1)
 {
	 Car_Go();
 }
}

