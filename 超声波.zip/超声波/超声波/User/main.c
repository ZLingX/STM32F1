#include "sys.h"

uint16_t Distance;

void HC_SR04_Init()
{
   	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitTypeDef  GPIO_InitStructure;
	
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;	 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(GPIOA, &GPIO_InitStructure);
 
	GPIO_ResetBits(GPIOA,GPIO_Pin_0);
//	GPIO_ResetBits(GPIOA,GPIO_Pin_1);
}

void HC_SR04_Start()
{
	GPIO_SetBits(GPIOA,GPIO_Pin_0);
	delay2_us(45);
	GPIO_ResetBits(GPIOA,GPIO_Pin_0);
	Distance=0;
}

uint16_t HCSR04_Get_Data()
{
	HC_SR04_Start();
	delay2_ms(100);
	return ((Distance * 0.0001) * 34000) / 2;
}

int main()
{
	delay_init();
	OLED_Init();
	OLED_Clear();
	MyTIM_Init(RCC_APB1Periph_TIM2,TIM2,7200,1,TIM2_IRQn,1,1);/*1ms*/
	HC_SR04_Init();
	
	while(1)
	{
		OLED_ShowNumber(0,0,HCSR04_Get_Data(),5,16);
	}
}

void TIM2_IRQHandler()/*1ms*/
{
	if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET)
	{ 
		
    if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)==1){Distance++;}
	}
  TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
}
