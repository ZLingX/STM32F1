#include <REGX52.H>
#include "INTRINS.h"
#include "Timer1.h"
#include "SR04.h"
#include "SG90.h"

sbit ENA=P1^0;
sbit IN1=P1^1;
sbit IN2=P1^2;
sbit IN3=P1^3;
sbit IN4=P1^4;
sbit ENB=P1^5;

float Dis,DisL,DisR,DisF;
unsigned char i,j,Count,Compare=35;
unsigned char PWMA,PWMB,Angle=22,Flag=0;

void Car_Run_Stop()
{
	PWMA=0;
	PWMB=0;
  IN1=0;
	IN2=0;
	IN3=0;
	IN4=0;
}

void Car_Run_Pos()
{
	PWMA=60;
	PWMB=60;
  IN1=0;
	IN2=1;
	IN3=1;
	IN4=0;
}

void Car_Run_Neg()
{
  IN1=1;
	IN2=0;
	IN3=0;
	IN4=1;
}

void Car_Turn_L()
{
	PWMA=60;
	PWMB=60;
  IN1=0;
	IN2=1;
	IN3=0;
	IN4=1;
}

void Car_Turn_R()
{
	PWMA=60;
	PWMB=60;
 	IN1=1;
	IN2=0;
	IN3=1;
	IN4=0;
}

void Delay(unsigned int T)//500ms
{
	unsigned char i;
	i=227;
  while(T--)
	{
	while (--i);
	}
}

void Car_Init()
{
	Timer1_Init();
	UltrasonicWave_Init();
}

void Car_Go()
{
	 Dis=UltrasonicWave_Measure();
	
	 if(Flag==0)
	 {
	  if(Dis/10>=30){Car_Run_Pos();}
	  if(Dis/10<30){Flag=1;}   
   }
	 
   if(Flag==1)
   {
		PWMA=60;PWMB=60;Car_Run_Neg();Delay(1);//急刹车
	  Car_Run_Stop();Delay(1);
		Flag=2;
	 }

	 if(Flag==2)
	 {
		 Angle=22;Delay(7);DisF=UltrasonicWave_Measure();
		 if(DisF/10<=15)
		 {
		   PWMA=50,PWMB=50;Car_Run_Neg();Delay(5);
			 Car_Run_Stop();Delay(1);Flag=3;
		 }		 
		 else{Flag=3;}
	 }
	 
	 if(Flag==3)
	 { 
		 Angle=32;Delay(7);DisL=UltrasonicWave_Measure();
		 Angle=13;Delay(7);DisR=UltrasonicWave_Measure();
		 Angle=22;Delay(7);
		 Flag=4;
	 }
		 
	 if(Flag==4)
	 {
	 	if(DisL>=DisR)
		{
			Car_Turn_L();Delay(3);
			Car_Run_Stop();Delay(2);
			Flag=0;
		}
		if(DisL<DisR)
		{
		 Car_Turn_R();Delay(3);
		 Car_Run_Stop();Delay(2);
		 Flag=0;
		}
	 }
}

void Timer1_Routine() interrupt 3
{
	TL1 = 0xA4;				//设置定时初始值
	TH1 = 0xFF;				//设置定时初始值
	
	Count++;
	if(Count>=200){Count=0;}
	if(Count<Angle){SG90=1;}
	else{SG90=0;}

	i++;
	j++;
	if(i>=100){i=0;}
	if(j>=100){j=0;}
	if(i<PWMA){ENA=1;}
	else {ENA=0;}
	if(j<PWMB){ENB=1;}
	else {ENB=0;}
}