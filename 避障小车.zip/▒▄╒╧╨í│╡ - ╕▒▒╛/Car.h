#ifndef __CAR_H_
#define __CAR_H_

void Car_Init();
void Car_Go();

#endif