#include <REGX52.H>

//void Timer1_Routine() interrupt 3
//{
//	TL1 = 0xA4;				//设置定时初始值
//	TH1 = 0xFF;				//设置定时初始值
//	
//	Count++;
//	if(Count>=200){Count=0;}
//	if(Count<Angle){SG90=1;}
//	else{SG90=0;}
//}
