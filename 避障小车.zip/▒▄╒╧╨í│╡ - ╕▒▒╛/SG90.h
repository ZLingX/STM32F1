#ifndef __SG90_H_
#define __SG90_H_

sbit SG90=P2^2;

#endif