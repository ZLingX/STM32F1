#include <REGX52.H>
#include <INTRINS.H>

sbit TRIG=P2^0;
sbit Echo=P2^1;

void Delay20us()		//@11.0592MHz
{
	unsigned char i;
	_nop_();
	i=6;while(--i);
}

void Timer0_Init()
{
	TMOD|=0x01;
	TH0=0x00;
	TL0=0x00;
	TR0=0;
}

void UltrasonicWave_Init()
{
	Timer0_Init();
	TRIG=0;
	Echo=0;
}

unsigned int UltrasonicWave_Measure()
{
	float Data;
	TRIG=0;
	Delay20us();
  TRIG=1;
	 
	while(Echo==0);
	TH0=0x00;
	TL0=0x00;
	TR0=1;
	while(Echo==1);
	TR0=0;
	
	Data=(TH0<<8)+TL0;
	Data=(Data*0.00034/2)*100;
	
	return Data*10;
}
