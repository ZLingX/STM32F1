#ifndef __SR04_H_
#define __SR04_H_

void UltrasonicWave_Init();
unsigned int UltrasonicWave_Measure();

#endif