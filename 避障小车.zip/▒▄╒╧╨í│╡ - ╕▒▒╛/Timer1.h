#ifndef __TIMER1_H_
#define __TIMER1_H_

void Timer1_Init();

#endif