#ifndef __INT0_H_
#define __INT0_H_

void Int0_Init();

#endif