#ifndef __KEY_H_
#define __KEY_H_
unsigned char Key();
#endif