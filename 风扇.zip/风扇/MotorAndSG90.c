#include <REGX52.H>
#include "Timer1.h"

sbit Motor=P1^0;
sbit SG90=P2^0;

unsigned char Counter1=1,Compare1;
unsigned int i,j=0,Compare2=12,Counter2,Time;

void MotorAndSG90_Init()
{
	Timer1_Init();
}

void Motor_SetSpeed(unsigned char Speed)
{
	Compare1=Speed;
}
	
void SG90_Turn_Run()
{
	j++;
  if(j>=2){j=0;}
}

void Timer1_Routine() interrupt 3
{
	TL1 = 0x9C;				//设置定时初始值
	TH1 = 0xFF;				//设置定时初始值

	if(j)
	{
		Time++;
		Counter2++;
		if(Counter2==800)
		{
			Counter2=0;
			if(i==0)
			{
				Compare2++;
				if(Compare2>=20)
				{i=1;}
			}
			
			if(i==1)
			{
				Compare2--;
				if(Compare2<=5)
				{i=0;}
			}
		}
		if(Time==200){Time=0;}
		if(Time<Compare2){SG90=1;}
		else{SG90=0;}
	}
	
	Counter1++;
  if(Counter1==100){Counter1=1;}
	if(Counter1<Compare1){Motor=1;}
	else{Motor=0;}
}
  