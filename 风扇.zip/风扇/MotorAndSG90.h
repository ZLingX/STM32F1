#ifndef __MOTORANDSG90_H_
#define __MOTORANDSG90_H_

void MotorAndSG90_Init();
void Motor_SetSpeed(unsigned char Speed);
void SG90_Turn_Run();

#endif