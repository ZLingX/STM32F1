#include <REGX52.H>
#include "MotorAndSG90.h"
#include "Delay.h"
#include "Nixie.h"
#include "Key.h"
#include "IR.h"

char KeyNum,Speed;
unsigned char Command;

void main()
{
	MotorAndSG90_Init();
	IR_Init();
  while(1)
 {
	 if(IR_GetDataFlag())
	 {
		  Command=IR_GetCommand();
			if(Command==IR_0){Speed=0;}
			if(Command==IR_1){Speed=1;}
			if(Command==IR_2){Speed=2;}
			if(Command==IR_3){Speed=3;}
			if(Command==IR_3){Speed=3;}
			if(Speed==0){Motor_SetSpeed(0); }
			if(Speed==1){Motor_SetSpeed(33);}
			if(Speed==2){Motor_SetSpeed(66);}
			if(Speed==3){Motor_SetSpeed(99);}
			if(Command==IR_NEXT){SG90_Turn_Run();}
	 } 
	 Nixie(1,Speed);
 }
}
